import streamlit as st
import os
from auth.authentication import login, check_auth
from auth.audit_log import AuditLogger

# ===== KONFIGURASI APLIKASI =====
st.set_page_config(page_title="Analytics Dashboard", layout="wide", page_icon="📊")

# ===== INISIALISASI LOGGER =====
logger = AuditLogger()

# ===== AUTENTIKASI =====
if not check_auth():
    login()
    st.stop()

# ===== LOG AKTIVITAS LOGIN (jika pertama kali masuk) =====
if not st.session_state.get("logged_event"):
    logger.log_action("login", f"User {st.session_state['user']} berhasil login")
    st.session_state["logged_event"] = True

# ===== TAMPILAN MENU UTAMA =====
st.header("Navigasi Fitur Utama")

# Daftar fitur
features = [
    {"name": "Dashboard Utama", "logo": "khs.png", "page": "pages/1_Dashboard.py"},
    {"name": "Analitik Web", "logo": "Dashboard.png", "page": "pages/5_WebAnalytics.py"},
    {"name": "YouTube Analytics", "logo": "youtube.png", "page": "pages/3_YouTube.py"},
    {"name": "AI Chatbot", "logo": "chatgpt.png", "page": "pages/2_Chatbot.py"},
    {"name": "Manajemen Data", "logo": "excel.png", "page": "pages/4_DataManager.py"},
]

# Tampilkan fitur dalam grid
cols = st.columns(len(features))
for idx, feature in enumerate(features):
    with cols[idx]:
        logo_path = os.path.join("assets", "logo", feature["logo"])
        if os.path.exists(logo_path):
            st.image(logo_path, use_column_width=True)
        else:
            st.warning(f"Logo tidak ditemukan: {feature['logo']}")

        if st.button(feature["name"], key=f"nav_{idx}"):
            logger.log_action("navigate", f"Mengakses fitur: {feature['name']}")
            st.switch_page(feature["page"])

# ===== HALAMAN UTAMA (Setelah Login) =====
st.title(f"Selamat Datang, {st.session_state.get('user', 'Pengguna')} 👋")
st.subheader("Pusat Analitik Terpadu")
st.info("Silakan pilih salah satu fitur di atas untuk memulai.")
