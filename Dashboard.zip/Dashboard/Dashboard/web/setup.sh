#!/bin/bash

# Exit immediately if a command exits with non-zero status
set -e

# Check if running in Heroku
if [[ -n "$DYNO" ]]; then
    echo "Running in Heroku environment"
    export STREAMLIT_SERVER_PORT=$PORT
    exec streamlit run streamlit_app.py --server.port $PORT
else
    echo "Running in Docker/other environment"
    
    # Start Nginx in background
    service nginx start
    
    # Start Streamlit
    streamlit run streamlit_app.py \
        --server.port=8501 \
        --server.headless=true \
        --server.enableCORS=false \
        --server.enableXsrfProtection=true
fi