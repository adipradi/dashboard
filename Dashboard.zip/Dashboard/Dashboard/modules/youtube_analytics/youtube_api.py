import os
from googleapiclient.discovery import build
from datetime import datetime, timedelta
import pandas as pd
from typing import Dict, List, Optional

class YouTubeAPI:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv('YOUTUBE_API_KEY')
        self.service = build('youtube', 'v3', developerKey=self.api_key)
    
    def get_channel_stats(self, channel_id: str) -> Dict:
        """Ambil statistik dasar channel"""
        request = self.service.channels().list(
            part="statistics,snippet",
            id=channel_id
        )
        response = request.execute()
        
        if not response.get('items'):
            return None
            
        data = response['items'][0]
        return {
            'channel_id': channel_id,
            'title': data['snippet']['title'],
            'subscribers': int(data['statistics']['subscriberCount']),
            'views': int(data['statistics']['viewCount']),
            'videos': int(data['statistics']['videoCount']),
            'thumbnail': data['snippet']['thumbnails']['high']['url'],
            'fetched_at': datetime.now()
        }
    
    def get_video_stats(self, video_id: str) -> Dict:
        """Ambil statistik video spesifik"""
        request = self.service.videos().list(
            part="statistics,snippet,contentDetails",
            id=video_id
        )
        response = request.execute()
        
        if not response.get('items'):
            return None
            
        data = response['items'][0]
        return {
            'video_id': video_id,
            'title': data['snippet']['title'],
            'views': int(data['statistics'].get('viewCount', 0)),
            'likes': int(data['statistics'].get('likeCount', 0)),
            'comments': int(data['statistics'].get('commentCount', 0)),
            'duration': self._parse_duration(data['contentDetails']['duration']),
            'published_at': data['snippet']['publishedAt'],
            'thumbnail': data['snippet']['thumbnails']['high']['url']
        }
    
    def get_channel_videos(self, channel_id: str, limit: int = 50) -> List[Dict]:
        """Ambil daftar video dari channel"""
        request = self.service.search().list(
            part="id,snippet",
            channelId=channel_id,
            maxResults=min(limit, 50),
            order="date",
            type="video"
        )
        response = request.execute()
        
        videos = []
        for item in response.get('items', []):
            if item['id']['kind'] == 'youtube#video':
                videos.append({
                    'video_id': item['id']['videoId'],
                    'title': item['snippet']['title'],
                    'published_at': item['snippet']['publishedAt'],
                    'thumbnail': item['snippet']['thumbnails']['high']['url']
                })
        
        return videos
    
    def _parse_duration(self, duration: str) -> int:
        """Parse duration ISO 8601 ke detik"""
        import isodate
        return int(isodate.parse_duration(duration).total_seconds())
    
    def get_trending_videos(self, region_code: str = "ID", limit: int = 10) -> pd.DataFrame:
        """Ambil video trending berdasarkan region"""
        request = self.service.videos().list(
            part="statistics,snippet,contentDetails",
            chart="mostPopular",
            regionCode=region_code,
            maxResults=limit
        )
        response = request.execute()
        
        videos = []
        for item in response.get('items', []):
            videos.append({
                'video_id': item['id'],
                'title': item['snippet']['title'],
                'channel': item['snippet']['channelTitle'],
                'views': int(item['statistics'].get('viewCount', 0)),
                'likes': int(item['statistics'].get('likeCount', 0)),
                'comments': int(item['statistics'].get('commentCount', 0)),
                'duration': self._parse_duration(item['contentDetails']['duration']),
                'published_at': item['snippet']['publishedAt']
            })
        
        return pd.DataFrame(videos)