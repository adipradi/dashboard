import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import logging
import numpy as np

class YouTubeVisualizer:
    def __init__(self, youtube_api):
        """
        Enhanced YouTube analytics visualizer with:
        - Comprehensive channel analytics
        - Advanced video performance metrics
        - Trending content analysis
        - Error handling and logging
        - Interactive visualizations
        """
        self.api = youtube_api
        self._configure_logging()
        self._setup_styles()

    def _configure_logging(self):
        """Configure logging for visualizer"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('youtube_visualizer')

    def _setup_styles(self):
        """Setup custom styles for visualizations"""
        st.markdown("""
        <style>
            .metric-card {
                padding: 15px;
                border-radius: 10px;
                background-color: #f8f9fa;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .metric-title {
                font-size: 14px;
                color: #6c757d;
                margin-bottom: 5px;
            }
            .metric-value {
                font-size: 24px;
                font-weight: bold;
            }
            .channel-header {
                display: flex;
                align-items: center;
                margin-bottom: 20px;
            }
            .channel-thumbnail {
                border-radius: 50%;
                margin-right: 20px;
            }
        </style>
        """, unsafe_allow_html=True)

    def show_channel_analytics(self, channel_id: str):
        """Display comprehensive channel analytics dashboard"""
        try:
            st.title("📈 YouTube Channel Analytics")
            
            # Get channel data
            channel_data = self._get_channel_data(channel_id)
            if not channel_data:
                return
                
            # Display channel header
            self._display_channel_header(channel_data)
            
            # Show metrics
            self._display_channel_metrics(channel_data)
            
            # Get videos data
            videos = self._get_channel_videos(channel_id)
            if not videos:
                return
                
            # Video analysis tabs
            tab1, tab2, tab3 = st.tabs(["Performance", "Engagement", "Trends"])
            
            with tab1:
                self._plot_video_performance(videos)
                
            with tab2:
                self._plot_engagement_metrics(videos)
                
            with tab3:
                self._plot_temporal_analysis(videos)
                
        except Exception as e:
            self.logger.error(f"Error displaying channel analytics: {e}")
            st.error("Terjadi kesalahan saat memuat analisis channel")

    def _get_channel_data(self, channel_id: str) -> Optional[Dict]:
        """Get channel data with error handling"""
        try:
            channel_data = self.api.get_channel_stats(channel_id)
            if not channel_data:
                st.error("Channel tidak ditemukan")
                return None
            return channel_data
        except Exception as e:
            self.logger.error(f"Error fetching channel data: {e}")
            st.error("Gagal memuat data channel")
            return None

    def _display_channel_header(self, channel_data: Dict):
        """Display channel header with thumbnail and info"""
        st.markdown(f"""
        <div class="channel-header">
            <img src="{channel_data['thumbnail']}" class="channel-thumbnail" width="100">
            <div>
                <h2>{channel_data['title']}</h2>
                <p>{channel_data['description']}</p>
            </div>
        </div>
        """, unsafe_allow_html=True)

    def _display_channel_metrics(self, channel_data: Dict):
        """Display channel metrics cards"""
        st.subheader("📊 Channel Metrics")
        
        # Calculate additional metrics
        avg_views = channel_data.get('avg_views', 0)
        view_growth = channel_data.get('view_growth', 0)
        sub_growth = channel_data.get('sub_growth', 0)
        
        # Display metrics
        cols = st.columns(4)
        metrics = [
            ("Subscribers", f"{channel_data['subscribers']:,}", "👥", f"{sub_growth:.1f}%"),
            ("Total Views", f"{channel_data['views']:,}", "👀", f"{view_growth:.1f}%"),
            ("Total Videos", channel_data['videos'], "🎬", None),
            ("Avg. Views", f"{avg_views:,.0f}", "📈", None)
        ]
        
        for i, (title, value, icon, change) in enumerate(metrics):
            with cols[i]:
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-title">{icon} {title}</div>
                    <div class="metric-value">{value}</div>
                    {f'<div style="color: {"green" if float(change or '0') >=0 else "red"}; font-size: 12px;">{change}</div>' if change else ''}
                </div>
                """, unsafe_allow_html=True)

    def _get_channel_videos(self, channel_id: str) -> Optional[pd.DataFrame]:
        """Get channel videos with stats"""
        try:
            videos = self.api.get_channel_videos(channel_id)
            if not videos:
                st.warning("Tidak ada video yang ditemukan")
                return None
                
            # Get detailed stats for each video
            video_stats = []
            for video in videos[:20]:  # Limit to 20 videos for performance
                stats = self.api.get_video_stats(video['video_id'])
                if stats:
                    video_stats.append(stats)
            
            if not video_stats:
                return None
                
            df = pd.DataFrame(video_stats)
            df['published_at'] = pd.to_datetime(df['published_at'])
            df['days_since_published'] = (datetime.now() - df['published_at']).dt.days
            df['views_per_day'] = df['views'] / df['days_since_published']
            df['engagement_rate'] = (df['likes'] + df['comments']) / df['views'] * 100
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error fetching video data: {e}")
            st.error("Gagal memuat data video")
            return None

    def _plot_video_performance(self, df: pd.DataFrame):
        """Plot video performance metrics"""
        st.subheader("📈 Video Performance")
        
        cols = st.columns(2)
        
        with cols[0]:
            # Top performing videos by views
            fig = px.bar(
                df.sort_values('views', ascending=False).head(10),
                x='title',
                y='views',
                title='Top Videos by Views',
                labels={'views': 'Total Views', 'title': 'Video Title'}
            )
            st.plotly_chart(fig, use_container_width=True)
            
        with cols[1]:
            # Views growth scatter plot
            fig = px.scatter(
                df,
                x='days_since_published',
                y='views',
                size='views',
                color='title',
                title='Views Growth Over Time',
                labels={'days_since_published': 'Days Since Published', 'views': 'Total Views'}
            )
            st.plotly_chart(fig, use_container_width=True)

    def _plot_engagement_metrics(self, df: pd.DataFrame):
        """Plot video engagement metrics"""
        st.subheader("❤️ Engagement Metrics")
        
        cols = st.columns(2)
        
        with cols[0]:
            # Likes vs Comments
            fig = px.bar(
                df,
                x='title',
                y=['likes', 'comments'],
                barmode='group',
                title='Likes vs Comments',
                labels={'value': 'Count', 'title': 'Video Title'}
            )
            st.plotly_chart(fig, use_container_width=True)
            
        with cols[1]:
            # Engagement rate
            fig = px.bar(
                df.sort_values('engagement_rate', ascending=False),
                x='title',
                y='engagement_rate',
                title='Engagement Rate (%)',
                labels={'engagement_rate': 'Engagement Rate', 'title': 'Video Title'}
            )
            st.plotly_chart(fig, use_container_width=True)

    def _plot_temporal_analysis(self, df: pd.DataFrame):
        """Plot temporal analysis of video performance"""
        st.subheader("⏳ Temporal Analysis")
        
        # Group by publish month
        df['publish_month'] = df['published_at'].dt.to_period('M').dt.to_timestamp()
        monthly_stats = df.groupby('publish_month').agg({
            'views': 'mean',
            'likes': 'mean',
            'engagement_rate': 'mean'
        }).reset_index()
        
        fig = px.line(
            monthly_stats,
            x='publish_month',
            y=['views', 'likes'],
            title='Monthly Performance Trends',
            labels={'value': 'Average Count', 'publish_month': 'Month'}
        )
        st.plotly_chart(fig, use_container_width=True)

    def show_trending_analysis(self, region_code: str = "ID"):
        """Display comprehensive trending videos analysis"""
        try:
            st.title("🔥 Trending Videos Analysis")
            
            # Get trending data
            df = self.api.get_trending_videos(region_code)
            if df.empty:
                st.warning("Tidak ada data trending yang ditemukan")
                return
                
            # Convert columns
            df['published_at'] = pd.to_datetime(df['published_at'])
            df['days_since_published'] = (datetime.now() - df['published_at']).dt.days
            df['views_per_day'] = df['views'] / df['days_since_published']
            
            # Show filters
            min_views = st.slider(
                "Minimum Views", 
                min_value=0, 
                max_value=int(df['views'].max()), 
                value=100000
            )
            filtered_df = df[df['views'] >= min_views]
            
            # Display metrics
            cols = st.columns(4)
            metrics = [
                ("Total Videos", len(filtered_df), "🎬"),
                ("Avg. Views", f"{filtered_df['views'].mean():,.0f}", "👀"),
                ("Avg. Likes", f"{filtered_df['likes'].mean():,.0f}", "👍"),
                ("Avg. Days Published", f"{filtered_df['days_since_published'].mean():.1f}", "📅")
            ]
            
            for i, (title, value, icon) in enumerate(metrics):
                with cols[i]:
                    st.markdown(f"""
                    <div class="metric-card">
                        <div class="metric-title">{icon} {title}</div>
                        <div class="metric-value">{value}</div>
                    </div>
                    """, unsafe_allow_html=True)
            
            # Display analysis tabs
            tab1, tab2 = st.tabs(["Data", "Analysis"])
            
            with tab1:
                st.dataframe(
                    filtered_df.sort_values('views', ascending=False),
                    column_config={
                        "views": st.column_config.NumberColumn(format="%,d"),
                        "likes": st.column_config.NumberColumn(format="%,d"),
                        "comments": st.column_config.NumberColumn(format="%,d"),
                        "published_at": st.column_config.DatetimeColumn()
                    },
                    hide_index=True,
                    use_container_width=True
                )
                
            with tab2:
                self._plot_trending_analysis(filtered_df)
                
        except Exception as e:
            self.logger.error(f"Error displaying trending analysis: {e}")
            st.error("Terjadi kesalahan saat memuat analisis trending")

    def _plot_trending_analysis(self, df: pd.DataFrame):
        """Plot trending videos analysis"""
        st.subheader("📊 Trending Videos Analysis")
        
        cols = st.columns(2)
        
        with cols[0]:
            # Views distribution
            fig = px.box(
                df,
                y='views',
                title='Views Distribution',
                points="all"
            )
            st.plotly_chart(fig, use_container_width=True)
            
        with cols[1]:
            # Views vs Days Published
            fig = px.scatter(
                df,
                x='days_since_published',
                y='views',
                size='likes',
                color='channel',
                hover_name='title',
                title='Views vs Days Published',
                labels={'days_since_published': 'Days Since Published', 'views': 'Total Views'}
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Top channels in trending
        st.subheader("Top Channels in Trending")
        channel_counts = df['channel'].value_counts().head(10).reset_index()
        fig = px.bar(
            channel_counts,
            x='channel',
            y='count',
            title='Channels with Most Trending Videos',
            labels={'count': 'Number of Videos', 'channel': 'Channel Name'}
        )
        st.plotly_chart(fig, use_container_width=True)