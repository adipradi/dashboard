# ui/chat_ui.py
import streamlit as st
from typing import Optional, Dict
from datetime import datetime
import logging
import time
from dateutil import parser

class ChatUI:
    def __init__(self, processor, history):
        self.processor = processor
        self.history = history
        self._configure_logging()
        self._setup_styles()

    def _configure_logging(self):
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('chat_ui')

    def _setup_styles(self):
        st.markdown("""
        <style>
            .chat-message { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem; animation: fadeIn 0.3s ease-in-out; }
            .user-message { background-color: #4a6bff; color: white; margin-left: 20%; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .bot-message { background-color: #f0f2f6; margin-right: 20%; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .typing-indicator { display: inline-block; padding: 0.5rem 1rem; background-color: #f0f2f6; border-radius: 1rem; margin-bottom: 1rem; }
            .dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: #666; margin: 0 2px; animation: bounce 1.4s infinite ease-in-out; }
            .dot:nth-child(2) { animation-delay: 0.2s; }
            .dot:nth-child(3) { animation-delay: 0.4s; }
            @keyframes bounce { 0%, 60%, 100% { transform: translateY(0); } 30% { transform: translateY(-5px); } }
            .timestamp { font-size: 0.7em; opacity: 0.7; text-align: right; margin-top: 0.5rem; }
        </style>
        """, unsafe_allow_html=True)

    def _format_timestamp(self, timestamp) -> str:
        try:
            if isinstance(timestamp, str):
                timestamp = parser.parse(timestamp)
            return timestamp.strftime("%d %b %Y, %H:%M")
        except:
            return str(timestamp)

    def display_chat_history(self, user_id: str, conversation_id: Optional[str] = None):
        try:
            history = self.history.get_history(user_id, conversation_id)
            if not history:
                st.info("💬 Mulai percakapan baru dengan mengetik pesan di bawah")
                return

            for msg in history:
                metadata = msg.get("metadata", {})
                meta_display = "<br>".join([f"<small><i>{k}: {v}</i></small>" for k, v in metadata.items()]) if isinstance(metadata, dict) else ""

                if msg["role"] == "user":
                    st.markdown(f"""
                    <div class="chat-message user-message">
                        <strong>Anda</strong><br>{msg['content']}
                        <div class="timestamp">{self._format_timestamp(msg['timestamp'])}</div>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="chat-message bot-message">
                        <strong>Asisten</strong><br>{msg['content']}<br>{meta_display}
                        <div class="timestamp">{self._format_timestamp(msg['timestamp'])}</div>
                    </div>
                    """, unsafe_allow_html=True)
        except Exception as e:
            self.logger.error(f"Error displaying chat history: {e}")
            st.error("❌ Gagal memuat histori")

    def show_typing_indicator(self):
        with st.empty():
            st.markdown("""
            <div class="typing-indicator">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
            """, unsafe_allow_html=True)
            time.sleep(0.5)

    def get_user_input(self) -> Optional[Dict]:
        with st.form("chat_form", clear_on_submit=True):
            cols = st.columns([0.85, 0.15])
            with cols[0]:
                prompt = st.text_area("Pesan Anda:", height=100, placeholder="Tulis sesuatu...", label_visibility="collapsed")
            with cols[1]:
                if st.form_submit_button("Kirim", use_container_width=True):
                    if prompt.strip():
                        return {"content": prompt.strip(), "timestamp": datetime.now()}
                    else:
                        st.warning("⚠️ Pesan tidak boleh kosong")
        return None

    def render_new_conversation_button(self):
        if st.button("🗨️ Percakapan Baru", use_container_width=True):
            st.session_state.current_conversation = None
            st.rerun()

    def render_conversation_selector(self, user_id: str):
        try:
            conversations = self.history.get_conversations(user_id)
            if conversations:
                options = {
                    conv["conversation_id"]: f"Percakapan {i+1} - {conv['last_activity']}"
                    for i, conv in enumerate(conversations)
                }
                return st.selectbox("Riwayat", list(options.keys()), format_func=lambda k: options[k])
        except Exception as e:
            self.logger.error(f"Error loading conversation list: {e}")
        return None
