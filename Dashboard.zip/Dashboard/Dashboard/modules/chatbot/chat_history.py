# modules/chatbot/chat_history.py

import sqlite3
from typing import List, Dict, Optional

class ChatHistory:
    def __init__(self, db_path='database/chat.db'):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

    def get_history(self, user_id: str, conversation_id: Optional[str] = None) -> List[Dict]:
        cursor = self.conn.cursor()
        if conversation_id:
            cursor.execute("""
                SELECT role, content, timestamp
                FROM chat_history
                WHERE user_id = ? AND conversation_id = ?
                ORDER BY timestamp ASC
            """, (user_id, conversation_id))
        else:
            cursor.execute("""
                SELECT role, content, timestamp
                FROM chat_history
                WHERE user_id = ?
                ORDER BY timestamp ASC
            """, (user_id,))
        return [dict(row) for row in cursor.fetchall()]

    def get_conversations(self, user_id: str) -> List[Dict]:
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT conversation_id, MAX(timestamp) AS last_activity
            FROM chat_history
            WHERE user_id = ?
            GROUP BY conversation_id
            ORDER BY last_activity DESC
        """, (user_id,))
        return [dict(row) for row in cursor.fetchall()]

    def save_message(self, user_id: str, role: str, content: str, conversation_id: str):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO chat_history (user_id, role, content, timestamp, conversation_id)
            VALUES (?, ?, ?, datetime('now'), ?)
        """, (user_id, role, content, conversation_id))
        self.conn.commit()
