from typing import Dict, Optional, List, Union
import openai  # or other model
from database.db_operations import DBOperations
import logging
import re
import pandas as pd
from datetime import datetime

class ChatProcessor:
    def __init__(self, db: DBOperations):
        """
        Enhanced Chat Processor with:
        - Better prompt engineering
        - Data analysis capabilities
        - Error handling
        - Response formatting
        - Usage tracking
        """
        self.db = db
        self._configure_logging()
        self.system_prompt = """
        Anda adalah asisten analisis data yang membantu pengguna memahami data mereka.
        Gunakan bahasa yang jelas dan sederhana. Jika menampilkan data, format dengan rapi.
        """

    def _configure_logging(self):
        """Configure logging for chat processor"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('chat_processor')

    def generate_response(self, user_id: str, prompt: str, conversation_context: Optional[List[Dict]] = None) -> Dict:
        """
        Generate response to user prompt with context awareness
        
        Args:
            user_id: ID of the user
            prompt: User's input message
            conversation_context: Previous messages in conversation
            
        Returns:
            Dictionary containing response and metadata
        """
        try:
            # Prepare messages with context
            messages = self._prepare_messages(prompt, conversation_context)
            
            # Check for data queries first
            data_response = self._process_data_query(prompt)
            if data_response:
                return self._format_data_response(data_response, prompt)

            # Generate LLM response
            response = self._call_llm(messages)
            
            # Post-process response
            processed_response = self._post_process_response(response, prompt)
            
            return {
                "role": "assistant",
                "content": processed_response,
                "metadata": {
                    "model": "gpt-4",
                    "tokens": response.usage.total_tokens,
                    "generated_at": datetime.now().isoformat(),
                    "response_type": "text"
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error generating response: {e}")
            return self._create_error_response()

    def _prepare_messages(self, prompt: str, context: Optional[List[Dict]]) -> List[Dict]:
        """Prepare message history for LLM context"""
        messages = [{"role": "system", "content": self.system_prompt}]
        
        if context:
            messages.extend(context[-5:])  # Use last 5 messages as context
            
        messages.append({"role": "user", "content": prompt})
        return messages

    def _call_llm(self, messages: List[Dict]):
        """Call the language model API"""
        return openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            temperature=0.7,
            max_tokens=1000
        )

    def _process_data_query(self, query: str) -> Optional[Union[pd.DataFrame, Dict]]:
        """
        Process data-specific queries and return results
        
        Returns:
            DataFrame if data found, None otherwise
        """
        try:
            query = query.lower()
            
            # Check for specific data patterns
            patterns = {
                "penjualan": r"(tampilkan|lihat|berapa).*(penjualan|sales)",
                "produk": r"(produk|item).*(terlaris|populer)",
                "pelanggan": r"(pelanggan|customer).*(aktif|baru)"
            }
            
            for table, pattern in patterns.items():
                if re.search(pattern, query):
                    data = self.db.get_data(
                        table_name=table,
                        limit=10,
                        order_by="tanggal DESC" if table == "penjualan" else None
                    )
                    if not data.empty:
                        return data
                    
            return None
            
        except Exception as e:
            self.logger.error(f"Error processing data query: {e}")
            return None

    def _format_data_response(self, data: pd.DataFrame, original_query: str) -> Dict:
        """
        Format data response with explanation
        """
        try:
            # Generate explanation from LLM
            explanation = self._generate_data_explanation(data, original_query)
            
            # Format data for display
            if len(data) > 5:
                data_sample = data.head(5)
                data_footnote = f"\n\nMenampilkan 5 dari {len(data)} baris data..."
            else:
                data_sample = data
                data_footnote = ""
                
            return {
                "role": "assistant",
                "content": (
                    f"{explanation}\n\n"
                    f"```\n{data_sample.to_markdown(index=False)}\n```"
                    f"{data_footnote}"
                ),
                "metadata": {
                    "model": "gpt-4 + data",
                    "tokens": 0,  # Will be updated after LLM call
                    "generated_at": datetime.now().isoformat(),
                    "response_type": "data",
                    "data_shape": data.shape
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error formatting data response: {e}")
            return self._create_error_response()

    def _generate_data_explanation(self, data: pd.DataFrame, query: str) -> str:
        """Generate natural language explanation of data"""
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Anda adalah asisten data yang menjelaskan hasil query."},
                    {"role": "user", "content": f"Jelaskan data berikut terkait dengan pertanyaan: '{query}'\n\nData:\n{data.head(5).to_markdown()}"}
                ],
                max_tokens=300
            )
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error generating data explanation: {e}")
            return "Berikut data yang diminta:"

    def _post_process_response(self, response: Dict, original_query: str) -> str:
        """Apply post-processing to LLM response"""
        content = response.choices[0].message.content
        
        # Add disclaimer for financial/medical queries
        sensitive_keywords = ["financial", "keuangan", "medical", "kesehatan", "medis"]
        if any(keyword in original_query.lower() for keyword in sensitive_keywords):
            content += "\n\nCatatan: Informasi ini bersifat umum dan bukan nasihat profesional."
            
        return content

    def _create_error_response(self) -> Dict:
        """Create error response when processing fails"""
        return {
            "role": "assistant",
            "content": "Maaf, terjadi kesalahan dalam memproses permintaan Anda. Silakan coba lagi.",
            "metadata": {
                "error": True,
                "generated_at": datetime.now().isoformat()
            }
        }