# modules/web_tracker.py

import streamlit as st
from datetime import datetime
import uuid
from database.db_operations import DBOperations
import user_agents
import logging
from typing import Optional, Dict, Any
import hashlib
import json

class WebTracker:
    def __init__(self, db: DBOperations):
        self.db = db
        self._configure_logging()

    def _configure_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('web_tracker')

    def _initialize_client(self):
        """Inisialisasi ID client dan session secara anonim"""
        if 'session_id' not in st.session_state:
            st.session_state.session_id = str(uuid.uuid4())
        if 'client_id' not in st.session_state:
            ip = st.session_state.get('client_ip', '')
            user_agent = st.session_state.get('user_agent', '')
            combined = f"{ip}-{user_agent}"
            st.session_state.client_id = hashlib.sha256(combined.encode()).hexdigest()

    def _get_client_info(self) -> Dict[str, Any]:
        """Ambil informasi klien dengan perlindungan privasi"""
        try:
            ua = user_agents.parse(st.session_state.get('user_agent', ''))
        except:
            ua = user_agents.parse('Mozilla/5.0')

        return {
            'session_id': st.session_state.get('session_id'),
            'client_id': st.session_state.get('client_id'),
            'user_id': st.session_state.get('user_id'),
            'ip_address': self._anonymize_ip(st.session_state.get('client_ip', '')),
            'device_type': self._get_device_type(ua),
            'browser_family': ua.browser.family,
            'browser_version': ua.browser.version_string,
            'os_family': ua.os.family,
            'os_version': ua.os.version_string,
            'is_mobile': ua.is_mobile,
            'is_tablet': ua.is_tablet,
            'is_pc': ua.is_pc,
            'is_bot': ua.is_bot,
            'screen_resolution': st.session_state.get('screen_resolution', '')
        }

    def _anonymize_ip(self, ip: str) -> str:
        if not ip or ip == 'unknown':
            return ip
        if ':' in ip:  # IPv6
            return ':'.join(ip.split(':')[:4]) + '::'
        return '.'.join(ip.split('.')[:2]) + '.0.0'

    def _get_device_type(self, ua) -> str:
        if ua.is_mobile: return 'mobile'
        if ua.is_tablet: return 'tablet'
        if ua.is_pc: return 'desktop'
        if ua.is_bot: return 'bot'
        return 'other'

    def track_pageview(self, page: str, referrer: Optional[str] = None) -> bool:
        try:
            self._initialize_client()
            if st.session_state.get('is_bot', False):
                return False

            client_info = self._get_client_info()

            pageview_data = {
                **client_info,
                'page_url': page,
                'referrer': referrer or st.session_state.get('referrer', ''),
                'timestamp': datetime.now(),
                'page_load_time': st.session_state.get('page_load_time'),
                'geo_location': st.session_state.get('geo_location', {}),
                'utm_source': st.session_state.get('utm_source'),
                'utm_medium': st.session_state.get('utm_medium'),
                'utm_campaign': st.session_state.get('utm_campaign'),
                'duration': st.session_state.get('page_duration')
            }

            success = self.db.add_record('page_views', pageview_data)
            if not success:
                self.logger.warning("Failed to record pageview")
                return False

            self.logger.info(f"Tracked pageview: {page}")
            return True

        except Exception as e:
            self.logger.error(f"Error tracking pageview: {e}")
            return False

    def track_event(
        self,
        event_name: str,
        category: Optional[str] = None,
        label: Optional[str] = None,
        value: Optional[float] = None,
        metadata: Optional[Dict] = None
    ) -> bool:
        try:
            if not event_name:
                raise ValueError("Event name is required")
            self._initialize_client()

            event_data = {
                **self._get_client_info(),
                'event_name': event_name,
                'event_category': category,
                'event_label': label,
                'event_value': value,
                'timestamp': datetime.now(),
                'metadata': json.dumps(metadata) if metadata else None
            }

            success = self.db.add_record('events', event_data)
            if not success:
                self.logger.warning(f"Failed to record event: {event_name}")
                return False

            self.logger.info(f"Tracked event: {event_name}")
            return True

        except Exception as e:
            self.logger.error(f"Error tracking event {event_name}: {e}")
            return False

    def track_error(
        self,
        error_type: str,
        message: str,
        stack_trace: Optional[str] = None,
        context: Optional[Dict] = None
    ) -> bool:
        return self.track_event(
            event_name="client_error",
            category=error_type,
            label=message,
            metadata={'stack_trace': stack_trace, **(context or {})}
        )
