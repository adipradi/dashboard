import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
import logging
from typing import Tuple, Optional
import numpy as np

class WebVisualizer:
    def __init__(self, db):
        """
        Enhanced web analytics visualizer with:
        - Comprehensive dashboard views
        - Interactive visualizations
        - Advanced metrics
        - Error handling
        - Custom time ranges
        """
        self.db = db
        self._configure_logging()
        self._setup_styles()

    def _configure_logging(self):
        """Configure logging for visualizer"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('web_visualizer')

    def _setup_styles(self):
        """Setup custom styles for visualizations"""
        st.markdown("""
        <style>
            .metric-card {
                padding: 15px;
                border-radius: 10px;
                background-color: #f8f9fa;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .metric-title {
                font-size: 14px;
                color: #6c757d;
                margin-bottom: 5px;
            }
            .metric-value {
                font-size: 24px;
                font-weight: bold;
            }
        </style>
        """, unsafe_allow_html=True)

    def show_analytics_dashboard(self, days: int = 7):
        """Display comprehensive analytics dashboard"""
        try:
            st.title("📈 Web Analytics Dashboard")
            
            # Date range selector
            col1, col2 = st.columns(2)
            with col1:
                start_date = st.date_input("Mulai", 
                    datetime.now() - timedelta(days=days))
            with col2:
                end_date = st.date_input("Selesai", datetime.now())
            
            # Convert to datetime
            start_dt = datetime.combine(start_date, datetime.min.time())
            end_dt = datetime.combine(end_date, datetime.max.time())
            
            # Get data
            df = self._get_analytics_data(start_dt, end_dt)
            
            if df.empty:
                st.warning("Tidak ada data yang ditemukan untuk periode ini")
                return
                
            # Show summary metrics
            self._display_summary_metrics(df)
            
            # Show main charts
            tab1, tab2, tab3 = st.tabs(["Traffic", "Audience", "Behavior"])
            
            with tab1:
                self._plot_traffic_analysis(df, start_dt, end_dt)
                
            with tab2:
                self._plot_audience_analysis(df)
                
            with tab3:
                self._plot_behavior_analysis(df)
                
        except Exception as e:
            self.logger.error(f"Error displaying dashboard: {e}")
            st.error("Terjadi kesalahan saat memuat dashboard")

    def _get_analytics_data(self, start_dt: datetime, end_dt: datetime) -> pd.DataFrame:
        """Get analytics data from database"""
        try:
            df = self.db.get_data(
                'page_views',
                filters={'timestamp': (start_dt, end_dt)},
                order_by="timestamp ASC"
            )
            
            # Add derived columns
            if not df.empty:
                df['date'] = df['timestamp'].dt.date
                df['hour'] = df['timestamp'].dt.hour
                df['is_new_visitor'] = ~df.duplicated('client_id', keep='first')
                
            return df
            
        except Exception as e:
            self.logger.error(f"Error fetching analytics data: {e}")
            return pd.DataFrame()

    def _display_summary_metrics(self, df: pd.DataFrame):
        """Display key metrics cards"""
        st.subheader("📊 Ringkasan Performa")
        
        # Calculate metrics
        metrics = self._calculate_metrics(df)
        
        # Display in columns
        cols = st.columns(4)
        metric_config = [
            ("Pengunjung", metrics['unique_visitors'], "👥"),
            ("Pageviews", metrics['pageviews'], "📄"),
            ("Sesi", metrics['sessions'], "🕒"),
            ("Durasi", f"{metrics['avg_session_duration']:.1f}m", "⏱️"),
            ("Bounce Rate", f"{metrics['bounce_rate']:.1f}%", "↩️"),
            ("Halaman/Sesi", f"{metrics['pages_per_session']:.1f}", "📊"),
            ("Pengunjung Baru", f"{metrics['new_visitors_pct']:.1f}%", "🆕"),
            ("Konversi", f"{metrics['conversion_rate']:.1f}%", "🎯")
        ]
        
        for i, (title, value, icon) in enumerate(metric_config):
            with cols[i % 4]:
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-title">{icon} {title}</div>
                    <div class="metric-value">{value}</div>
                </div>
                """, unsafe_allow_html=True)

    def _calculate_metrics(self, df: pd.DataFrame) -> dict:
        """Calculate all key metrics from data"""
        metrics = {
            'unique_visitors': df['client_id'].nunique(),
            'pageviews': len(df),
            'sessions': df['session_id'].nunique(),
            'avg_session_duration': self._calculate_avg_session_duration(df) / 60,
            'bounce_rate': self._calculate_bounce_rate(df) * 100,
            'pages_per_session': len(df) / df['session_id'].nunique(),
            'new_visitors_pct': df['is_new_visitor'].mean() * 100,
            'conversion_rate': 0  # Placeholder - implement your conversion logic
        }
        return metrics

    def _calculate_avg_session_duration(self, df: pd.DataFrame) -> float:
        """Calculate average session duration in seconds"""
        if 'session_id' not in df.columns:
            return 0
            
        session_durations = df.groupby('session_id')['timestamp'].agg(
            lambda x: (x.max() - x.min()).total_seconds()
        )
        return session_durations.mean() if not session_durations.empty else 0

    def _calculate_bounce_rate(self, df: pd.DataFrame) -> float:
        """Calculate bounce rate (single-page sessions)"""
        if 'session_id' not in df.columns:
            return 0
            
        session_counts = df['session_id'].value_counts()
        single_page_sessions = (session_counts == 1).sum()
        total_sessions = len(session_counts)
        
        return single_page_sessions / total_sessions if total_sessions > 0 else 0

    def _plot_traffic_analysis(self, df: pd.DataFrame, start_dt: datetime, end_dt: datetime):
        """Plot traffic analysis charts"""
        st.subheader("🚦 Analisis Traffic")
        
        # Time series chart
        time_grouping = "date" if (end_dt - start_dt).days > 7 else "hour"
        df_grouped = df.groupby(pd.Grouper(key='timestamp', freq='D' if time_grouping == "date" else 'H')).size().reset_index(name='count')
        
        fig = px.area(
            df_grouped,
            x='timestamp',
            y='count',
            title='Traffic Over Time',
            labels={'count': 'Pageviews', 'timestamp': 'Waktu'}
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Traffic sources
        if 'referrer' in df.columns:
            st.subheader("Sumber Traffic")
            referrer_counts = df['referrer'].value_counts().head(10).reset_index()
            fig = px.bar(
                referrer_counts,
                x='referrer',
                y='count',
                labels={'referrer': 'Sumber', 'count': 'Kunjungan'}
            )
            st.plotly_chart(fig, use_container_width=True)

    def _plot_audience_analysis(self, df: pd.DataFrame):
        """Plot audience analysis charts"""
        st.subheader("👥 Analisis Audiens")
        
        cols = st.columns(2)
        
        with cols[0]:
            # Device distribution
            if 'device_type' in df.columns:
                device_counts = df['device_type'].value_counts().reset_index()
                fig = px.pie(
                    device_counts,
                    names='device_type',
                    values='count',
                    title='Distribusi Perangkat'
                )
                st.plotly_chart(fig, use_container_width=True)
        
        with cols[1]:
            # Browser/OS distribution
            if 'browser_family' in df.columns:
                browser_counts = df['browser_family'].value_counts().head(5).reset_index()
                fig = px.bar(
                    browser_counts,
                    x='browser_family',
                    y='count',
                    title='Browser Teratas'
                )
                st.plotly_chart(fig, use_container_width=True)

    def _plot_behavior_analysis(self, df: pd.DataFrame):
        """Plot user behavior analysis"""
        st.subheader("🧭 Analisis Perilaku")
        
        # Top pages
        if 'page_url' in df.columns:
            page_counts = df['page_url'].value_counts().head(10).reset_index()
            fig = px.bar(
                page_counts,
                x='page_url',
                y='count',
                title='Halaman Terpopuler',
                labels={'page_url': 'Halaman', 'count': 'Kunjungan'}
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Session duration distribution
        if 'session_id' in df.columns:
            session_durations = df.groupby('session_id')['timestamp'].agg(
                lambda x: (x.max() - x.min()).total_seconds()
            )
            fig = px.histogram(
                x=session_durations,
                nbins=20,
                title='Distribusi Durasi Sesi',
                labels={'x': 'Durasi (detik)'}
            )
            st.plotly_chart(fig, use_container_width=True)