import pandas as pd
from datetime import datetime
import re
import json
from typing import Union, Dict, List, Optional
import logging
from dateutil.parser import parse as parse_date

class LogParser:
    """
    Enhanced log parser with:
    - Multiple log format support
    - Better error handling
    - Data validation
    - Timestamp parsing
    - User agent analysis
    """
    
    def __init__(self):
        self._configure_logging()
        
    def _configure_logging(self):
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('log_parser')

    @staticmethod
    def _parse_nginx_common(log_line: str) -> Optional[Dict]:
        pattern = (
            r'(?P<ip>\S+) - (?P<user>\S+) \[(?P<timestamp>.*?)\] '
            r'"(?P<method>\S+) (?P<url>\S+) HTTP/(?P<http_version>\d\.\d)" '
            r'(?P<status>\d+) (?P<size>\d+) '
            r'"(?P<referrer>.*?)" "(?P<user_agent>.*?)"'
        )
        match = re.match(pattern, log_line)
        return match.groupdict() if match else None

    @staticmethod
    def _parse_nginx_combined(log_line: str) -> Optional[Dict]:
        pattern = (
            r'(?P<ip>\S+) - (?P<user>\S+) \[(?P<timestamp>.*?)\] '
            r'"(?P<method>\S+) (?P<url>\S+) HTTP/(?P<http_version>\d\.\d)" '
            r'(?P<status>\d+) (?P<size>\d+) '
            r'"(?P<referrer>.*?)" "(?P<user_agent>.*?)" '
            r'(?P<request_time>\S+) (?P<upstream_time>\S+)'
        )
        match = re.match(pattern, log_line)
        return match.groupdict() if match else None

    def parse_nginx(self, log_line: str, format_type: str = 'combined') -> Dict:
        try:
            result = self._parse_nginx_common(log_line) if format_type == 'common' else self._parse_nginx_combined(log_line)
            if not result:
                raise ValueError("Failed to parse log line")

            result['timestamp'] = parse_date(result['timestamp'].split()[0])
            for field in ['status', 'size']:
                if field in result:
                    result[field] = int(result[field])
            for field in ['request_time', 'upstream_time']:
                if field in result and result[field] != '-':
                    result[field] = float(result[field])
            return result

        except Exception as e:
            self.logger.error(f"Error parsing Nginx log: {e}")
            return {'error': True, 'message': str(e), 'raw_log': log_line}

    def parse_log_file(self, file_path: str, format_type: str = 'combined') -> pd.DataFrame:
        try:
            with open(file_path, 'r') as f:
                logs = [self.parse_nginx(line.strip(), format_type) for line in f]
            valid_logs = [log for log in logs if not log.get('error')]
            return pd.DataFrame(valid_logs)
        except Exception as e:
            self.logger.error(f"Error parsing log file: {e}")
            raise

class GAParser:
    """
    Enhanced Google Analytics parser with:
    - Better response validation
    - Metric/dimension handling
    - Data type conversion
    - Pagination support
    """
    
    def __init__(self):
        self._configure_logging()
        
    def _configure_logging(self):
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('ga_parser')

    def parse_ga_response(self, response: Union[dict, str], convert_types: bool = True) -> pd.DataFrame:
        try:
            data = self._load_response(response)
            report = data.get('reports', [{}])[0]
            dimensions = report['columnHeader'].get('dimensions', [])
            metrics = [
                m['name'] for m in report['columnHeader']['metricHeader']['metricHeaderEntries']
            ]
            columns = dimensions + metrics

            rows = []
            for row in report.get('data', {}).get('rows', []):
                row_data = row.get('dimensions', []) + row.get('metrics', [{}])[0].get('values', [])
                rows.append(row_data)

            df = pd.DataFrame(rows, columns=columns)
            return self._convert_data_types(df) if convert_types else df

        except Exception as e:
            self.logger.error(f"Error parsing GA response: {e}")
            raise

    def _load_response(self, response: Union[dict, str]) -> dict:
        if isinstance(response, str):
            try:
                return json.loads(response)
            except json.JSONDecodeError:
                self.logger.error("Invalid JSON response")
                raise
        return response

    def _convert_data_types(self, df: pd.DataFrame) -> pd.DataFrame:
        for col in df.columns:
            if col.endswith('date') or col.endswith('Date'):
                try:
                    df[col] = pd.to_datetime(df[col])
                except:
                    continue
            elif any(term in col.lower() for term in ['metric', 'count', 'total']):
                df[col] = pd.to_numeric(df[col], errors='ignore')
        return df

    def parse_multiple_reports(self, responses: List[Union[dict, str]]) -> Dict[str, pd.DataFrame]:
        try:
            return {
                f"report_{i}": self.parse_ga_response(response)
                for i, response in enumerate(responses, 1)
            }
        except Exception as e:
            self.logger.error(f"Error parsing multiple reports: {e}")
            raise
