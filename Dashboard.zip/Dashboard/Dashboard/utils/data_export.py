import pandas as pd
import streamlit as st
from datetime import datetime
from io import BytesIO
from typing import Union, Optional, List, Dict, Tuple
import logging
import json
import numpy as np
from pandas.api.types import is_datetime64_any_dtype as is_datetime

class DataExporter:
    """Enhanced data exporter with support for multiple formats and advanced features"""
    
    @staticmethod
    def _sanitize_filename(filename: str) -> str:
        """Sanitize filename by removing special characters"""
        keep_chars = (' ', '.', '_', '-')
        return "".join(c for c in filename if c.isalnum() or c in keep_chars).rstrip()

    @staticmethod
    def _handle_datetime_columns(df: pd.DataFrame) -> pd.DataFrame:
        """Convert datetime columns to strings for better export"""
        df = df.copy()
        for col in df.columns:
            if is_datetime(df[col]):
                df[col] = df[col].dt.strftime('%Y-%m-%d %H:%M:%S')
        return df

    @staticmethod
    def to_csv(
        df: pd.DataFrame,
        filename: Optional[str] = None,
        index: bool = False,
        encoding: str = 'utf-8'
    ) -> Tuple[BytesIO, str]:
        """Convert DataFrame to CSV download with enhanced options
        
        Args:
            df: DataFrame to export
            filename: Optional output filename
            index: Whether to include index
            encoding: File encoding
            
        Returns:
            Tuple of (BytesIO object, filename)
        """
        try:
            if filename is None:
                filename = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            else:
                filename = DataExporter._sanitize_filename(filename)
                if not filename.endswith('.csv'):
                    filename += '.csv'
            
            df = DataExporter._handle_datetime_columns(df)
            csv = df.to_csv(index=index, encoding=encoding).encode(encoding)
            return BytesIO(csv), filename
            
        except Exception as e:
            logging.error(f"CSV export failed: {e}")
            raise

    @staticmethod
    def to_excel(
        df: pd.DataFrame,
        filename: Optional[str] = None,
        sheet_name: str = 'Data',
        index: bool = False,
        **kwargs
    ) -> Tuple[BytesIO, str]:
        """Convert DataFrame to Excel download with enhanced options
        
        Args:
            df: DataFrame to export
            filename: Optional output filename
            sheet_name: Name of the Excel sheet
            index: Whether to include index
            **kwargs: Additional pandas ExcelWriter parameters
            
        Returns:
            Tuple of (BytesIO object, filename)
        """
        try:
            if filename is None:
                filename = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            else:
                filename = DataExporter._sanitize_filename(filename)
                if not filename.lower().endswith(('.xlsx', '.xls')):
                    filename += '.xlsx'
            
            df = DataExporter._handle_datetime_columns(df)
            output = BytesIO()
            
            with pd.ExcelWriter(output, engine='xlsxwriter', **kwargs) as writer:
                df.to_excel(writer, index=index, sheet_name=sheet_name)
                
                # Auto-adjust column widths
                worksheet = writer.sheets[sheet_name]
                for i, col in enumerate(df.columns):
                    max_len = max((
                        df[col].astype(str).str.len().max(),
                        len(str(col))
                    )) + 2  # Add padding
                    worksheet.set_column(i, i, max_len)
            
            return output, filename
            
        except Exception as e:
            logging.error(f"Excel export failed: {e}")
            raise

    @staticmethod
    def to_json(
        df: pd.DataFrame,
        filename: Optional[str] = None,
        orient: str = 'records',
        **kwargs
    ) -> Tuple[BytesIO, str]:
        """Convert DataFrame to JSON download
        
        Args:
            df: DataFrame to export
            filename: Optional output filename
            orient: JSON orientation (records, split, index, etc.)
            **kwargs: Additional pandas to_json parameters
            
        Returns:
            Tuple of (BytesIO object, filename)
        """
        try:
            if filename is None:
                filename = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            else:
                filename = DataExporter._sanitize_filename(filename)
                if not filename.endswith('.json'):
                    filename += '.json'
            
            json_str = df.to_json(orient=orient, **kwargs)
            return BytesIO(json_str.encode('utf-8')), filename
            
        except Exception as e:
            logging.error(f"JSON export failed: {e}")
            raise

    @staticmethod
    def create_download_button(
        df: pd.DataFrame,
        file_type: str = 'csv',
        button_text: str = "Download Data",
        key: Optional[str] = None,
        **kwargs
    ):
        """Create Streamlit download button with enhanced options
        
        Args:
            df: DataFrame to export
            file_type: Export format (csv, excel, json)
            button_text: Text to display on button
            key: Unique key for Streamlit component
            **kwargs: Additional format-specific parameters
        """
        try:
            if file_type.lower() == 'csv':
                data, filename = DataExporter.to_csv(df, **kwargs)
                mime_type = "text/csv"
            elif file_type.lower() in ('excel', 'xlsx'):
                data, filename = DataExporter.to_excel(df, **kwargs)
                mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            elif file_type.lower() == 'json':
                data, filename = DataExporter.to_json(df, **kwargs)
                mime_type = "application/json"
            else:
                raise ValueError(f"Unsupported file type: {file_type}. Choose 'csv', 'excel', or 'json'")
            
            st.download_button(
                label=button_text,
                data=data,
                file_name=filename,
                mime=mime_type,
                key=key,
                use_container_width=True
            )
            
        except Exception as e:
            st.error(f"Failed to create download: {str(e)}")
            logging.error(f"Download button creation failed: {e}")

    @staticmethod
    def export_multiple_sheets(
        sheet_dict: Dict[str, pd.DataFrame],
        filename: Optional[str] = None,
        **kwargs
    ) -> Tuple[BytesIO, str]:
        """Export multiple DataFrames to Excel with different sheets
        
        Args:
            sheet_dict: Dictionary of {sheet_name: DataFrame}
            filename: Optional output filename
            **kwargs: Additional ExcelWriter parameters
            
        Returns:
            Tuple of (BytesIO object, filename)
        """
        try:
            if filename is None:
                filename = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            else:
                filename = DataExporter._sanitize_filename(filename)
                if not filename.lower().endswith(('.xlsx', '.xls')):
                    filename += '.xlsx'
            
            output = BytesIO()
            
            with pd.ExcelWriter(output, engine='xlsxwriter', **kwargs) as writer:
                for sheet_name, df in sheet_dict.items():
                    df = DataExporter._handle_datetime_columns(df)
                    df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
                    
                    # Auto-adjust column widths
                    worksheet = writer.sheets[sheet_name[:31]]
                    for i, col in enumerate(df.columns):
                        max_len = max((
                            df[col].astype(str).str.len().max(),
                            len(str(col))
                        )) + 2
                        worksheet.set_column(i, i, max_len)
            
            return output, filename
            
        except Exception as e:
            logging.error(f"Multi-sheet export failed: {e}")
            raise