import os
from dotenv import load_dotenv
from pathlib import Path
from typing import Any, Dict
import logging
import json
from functools import lru_cache

class Config:
    """Enhanced centralized configuration management with:
    - Environment variable loading
    - Type conversion
    - Secret management
    - Configuration validation
    - Caching
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        """Initialize configuration with validation"""
        self._load_env()
        self._validate_config()
        self._setup_logging()

    def _load_env(self):
        """Load configuration from multiple sources"""
        env_path = Path('.env')
        if env_path.exists():
            load_dotenv(env_path)
        else:
            load_dotenv()

        self.DB_CONFIG = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'user': os.getenv('DB_USER', 'admin'),
            'password': os.getenv('DB_PASSWORD', '123456'),
            'database': os.getenv('DB_NAME', 'dashboard_db'),
            'port': self._convert_type(os.getenv('DB_PORT', '3306'), int),
            'pool_size': self._convert_type(os.getenv('DB_POOL_SIZE', '5'), int),
            'connect_timeout': self._convert_type(os.getenv('DB_TIMEOUT', '30'), int)
        }

        self.APP_CONFIG = {
            'debug': self._convert_type(os.getenv('DEBUG', 'False'), bool),
            'log_level': os.getenv('LOG_LEVEL', 'INFO').upper(),
            'env': os.getenv('APP_ENV', 'development'),
            'secret_key': os.getenv('APP_SECRET_KEY'),
            'allowed_hosts': json.loads(os.getenv('ALLOWED_HOSTS', '"[\"*"]"'))
        }

        self.API_KEYS = {
            'youtube': os.getenv('YOUTUBE_API_KEY'),
            'google_analytics': os.getenv('GA_API_KEY'),
            'openai': os.getenv('OPENAI_API_KEY')
        }

        self.SERVICES = {
            'cache': {
                'host': os.getenv('REDIS_HOST', 'localhost'),
                'port': self._convert_type(os.getenv('REDIS_PORT', '6379'), int),
                'db': self._convert_type(os.getenv('REDIS_DB', '0'), int)
            },
            'storage': {
                'bucket': os.getenv('STORAGE_BUCKET'),
                'credentials': os.getenv('STORAGE_CREDENTIALS_JSON')
            }
        }

    def _convert_type(self, value: str, target_type: type) -> Any:
        try:
            if target_type == bool:
                return value.lower() in ('true', '1', 't', 'y', 'yes')
            return target_type(value)
        except (ValueError, TypeError):
            logging.warning(f"Failed to convert {value} to {target_type}")
            return None

    def _validate_config(self):
        if not self.DB_CONFIG['database']:
            logging.error("Database name not configured")

        if self.APP_CONFIG['env'] == 'production' and not self.APP_CONFIG['secret_key']:
            logging.error("Secret key required in production mode")

        if not self.API_KEYS['youtube']:
            logging.warning("YouTube API key not configured - YouTube features will be disabled")

    def _setup_logging(self):
        logging.basicConfig(
            level=self.APP_CONFIG['log_level'],
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

    @lru_cache(maxsize=32)
    def get(self, key: str, default: Any = None) -> Any:
        try:
            keys = key.split('.')
            value = self.__dict__
            for k in keys:
                if isinstance(value, dict) and k in value:
                    value = value[k]
                else:
                    return default
            return value
        except Exception as e:
            logging.error(f"Error accessing config key {key}: {e}")
            return default

    def reload(self):
        self._instance = None
        self._initialize()
        logging.info("Configuration reloaded")

    def is_production(self) -> bool:
        return self.APP_CONFIG['env'].lower() == 'production'

    def is_debug(self) -> bool:
        return self.APP_CONFIG['debug']

    def get_service_config(self, service_name: str) -> Dict[str, Any]:
        return self.SERVICES.get(service_name, {})
