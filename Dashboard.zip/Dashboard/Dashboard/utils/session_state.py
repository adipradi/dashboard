import streamlit as st
from typing import Any, Dict, Optional
import hashlib
import json

class SessionManager:
    """Enhanced session state management with type hints"""
    
    def __init__(self, secret_key: Optional[str] = None):
        self.secret_key = secret_key
    
    def __getitem__(self, key: str) -> Any:
        if key not in st.session_state:
            raise KeyError(f"Session key '{key}' not found")
        return st.session_state[key]
    
    def __setitem__(self, key: str, value: Any):
        st.session_state[key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """Safely get session value with default"""
        return st.session_state.get(key, default)
    
    def set_multi(self, items: Dict[str, Any]):
        """Set multiple session values at once"""
        for key, value in items.items():
            st.session_state[key] = value
    
    def clear(self, *keys: str):
        """Clear specific session keys or all if none provided"""
        if not keys:
            st.session_state.clear()
        else:
            for key in keys:
                if key in st.session_state:
                    del st.session_state[key]
    
    def generate_session_token(self, data: Dict) -> str:
        """Generate hashed session token"""
        if not self.secret_key:
            raise ValueError("Secret key required for token generation")
        
        payload = json.dumps(data, sort_keys=True).encode()
        return hashlib.sha256(payload + self.secret_key.encode()).hexdigest()