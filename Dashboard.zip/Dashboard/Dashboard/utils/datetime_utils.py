from datetime import datetime, timedelta
from typing import Union
import pytz

def format_datetime(
    dt: Union[datetime, str], 
    fmt: str = "%Y-%m-%d %H:%M:%S",
    timezone: str = "UTC"
) -> str:
    """Format datetime object or string"""
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)
    
    if timezone:
        tz = pytz.timezone(timezone)
        dt = dt.astimezone(tz)
    
    return dt.strftime(fmt)

def humanize_timedelta(td: timedelta) -> str:
    """Convert timedelta to human-readable format"""
    seconds = int(td.total_seconds())
    periods = [
        ('year', 60*60*24*365),
        ('month', 60*60*24*30),
        ('day', 60*60*24),
        ('hour', 60*60),
        ('minute', 60),
        ('second', 1)
    ]
    
    parts = []
    for period_name, period_seconds in periods:
        if seconds >= period_seconds:
            period_value, seconds = divmod(seconds, period_seconds)
            parts.append(f"{period_value} {period_name}{'s' if period_value != 1 else ''}")
    
    return ", ".join(parts[:2]) if parts else "just now"