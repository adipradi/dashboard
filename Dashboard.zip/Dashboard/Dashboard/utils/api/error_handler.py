import requests
from typing import Dict, Any

class APIErrorHandler:
    """Standardized API error handling"""
    
    @staticmethod
    def handle_http_error(response: requests.Response) -> Dict[str, Any]:
        """Handle HTTP errors and return standardized response"""
        try:
            error_data = response.json()
        except ValueError:
            error_data = {'message': response.text}
        
        return {
            'error': True,
            'status_code': response.status_code,
            'data': error_data,
            'message': f"HTTP Error {response.status_code}: {response.reason}"
        }