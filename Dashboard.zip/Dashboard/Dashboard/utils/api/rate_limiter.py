import time
from collections import defaultdict

class RateLimiter:
    """API rate limiting utility"""
    
    def __init__(self, max_calls: int, period: float):
        self.max_calls = max_calls
        self.period = period
        self._calls = defaultdict(list)
    
    def __call__(self, identifier: str) -> bool:
        """Check if call is allowed"""
        now = time.time()
        calls = self._calls[identifier]
        
        # Remove outdated calls
        calls = [t for t in calls if t > now - self.period]
        self._calls[identifier] = calls
        
        if len(calls) >= self.max_calls:
            return False
        
        calls.append(now)
        return True