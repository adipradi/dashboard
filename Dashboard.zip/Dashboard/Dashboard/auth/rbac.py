import streamlit as st
from typing import List, Dict, Callable, Any, Set, Optional, Tuple
from functools import wraps
import logging
from enum import Enum

# Custom error for denied access
class PermissionDeniedError(Exception):
    pass

# Role Enum: safer than plain strings
class Role(str, Enum):
    ADMIN = "admin"
    MARKETING = "marketing"
    ACCOUNTING = "akuntansi"
    VIEWER = "viewer"
    GUEST = "guest"

class RBAC:
    """
    Role-Based Access Control:
    - Enum-safe roles
    - Role hierarchy & inheritance
    - Permission decorators
    - Streamlit error handling
    """
    # Role inheritance
    ROLE_HIERARCHY: Dict[Role, List[Role]] = {
        Role.ADMIN: [Role.MARKETING, Role.ACCOUNTING, Role.VIEWER],
        Role.MARKETING: [Role.VIEWER],
        Role.ACCOUNTING: [Role.VIEWER],
        Role.VIEWER: [],
        Role.GUEST: []
    }

    # Permissions with metadata
    PERMISSIONS: Dict[str, Dict] = {
        "user_management": {
            "description": "Manage user accounts and roles",
            "roles": [Role.ADMIN],
            "category": "administration"
        },
        "data_access": {
            "description": "Access sensitive data",
            "roles": [Role.ADMIN, Role.ACCOUNTING],
            "category": "data"
        },
        "analytics": {
            "description": "View analytics dashboards",
            "roles": [Role.ADMIN, Role.MARKETING],
            "category": "analytics"
        },
        "chatbot": {
            "description": "Access AI chatbot features",
            "roles": [Role.ADMIN, Role.MARKETING],
            "category": "features"
        },
        "web_analytics": {
            "description": "Access web traffic analytics",
            "roles": [Role.ADMIN, Role.MARKETING],
            "category": "analytics"
        },
        "youtube": {
            "description": "Access YouTube analytics",
            "roles": [Role.ADMIN, Role.MARKETING],
            "category": "analytics"
        },
        "view_reports": {
            "description": "View read-only reports",
            "roles": [Role.ADMIN, Role.MARKETING, Role.ACCOUNTING, Role.VIEWER],
            "category": "reports"
        }
    }

    _role_cache: Dict[Role, Set[Role]] = {}

    @classmethod
    def _get_user_roles(cls, role: Role) -> Set[Role]:
        """Get all roles including inherited ones"""
        if role in cls._role_cache:
            return cls._role_cache[role]

        inherited = set()
        stack = [role]
        while stack:
            current = stack.pop()
            if current not in inherited:
                inherited.add(current)
                stack.extend(cls.ROLE_HIERARCHY.get(current, []))

        cls._role_cache[role] = inherited
        return inherited

    @classmethod
    def has_permission(cls, permission_name: str, raise_exception: bool = False) -> Callable:
        """
        Decorator to protect Streamlit functions
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                raw_role = st.session_state.get("role", Role.GUEST.value)
                try:
                    user_role = Role(raw_role)
                except ValueError:
                    user_role = Role.GUEST

                username = st.session_state.get("username", "unknown")

                has_access, message = cls.check_permission(permission_name, user_role)

                if has_access:
                    logging.info(f"[RBAC] ✅ Access granted: {username} ({user_role}) -> {permission_name}")
                    return func(*args, **kwargs)
                else:
                    logging.warning(f"[RBAC] ❌ Access denied: {username} ({user_role}) -> {permission_name}")
                    if raise_exception:
                        raise PermissionDeniedError(message)
                    else:
                        st.error(message)
                        st.stop()
            return wrapper
        return decorator

    @classmethod
    def check_permission(cls, permission_name: str, role: Role) -> Tuple[bool, str]:
        """
        Direct permission check for a given role
        """
        perm = cls.PERMISSIONS.get(permission_name)
        if not perm:
            return False, f"⚠️ Permission '{permission_name}' tidak ditemukan"

        user_roles = cls._get_user_roles(role)
        allowed_roles = set(perm["roles"])

        if user_roles.intersection(allowed_roles):
            return True, "✅ Akses diizinkan"
        else:
            required = ", ".join([r.value for r in allowed_roles])
            return False, (
                f"🚫 Akses Ditolak\n"
                f"Anda tidak memiliki izin untuk fitur ini.\n"
                f"Role yang dibutuhkan: {required}"
            )

    @classmethod
    def get_all_permissions(cls) -> Dict[str, Dict]:
        return cls.PERMISSIONS

    @classmethod
    def get_user_permissions(cls, role: Role) -> Dict[str, Dict]:
        user_roles = cls._get_user_roles(role)
        return {
            name: meta for name, meta in cls.PERMISSIONS.items()
            if user_roles.intersection(set(meta["roles"]))
        }

    @classmethod
    def get_role_hierarchy(cls) -> Dict[Role, List[Role]]:
        return cls.ROLE_HIERARCHY


# Test use
if __name__ == "__main__":
    # Simulasi session untuk lokal test
    st.session_state.role = "marketing"
    st.session_state.username = "tester"

    @RBAC.has_permission("analytics")
    def test_feature():
        st.success("Fitur analytics berhasil diakses!")

    test_feature()

    has_access, msg = RBAC.check_permission("data_access", Role.MARKETING)
    st.write(f"Marketing akses data_access? {has_access} - {msg}")
