import logging
from auth.password_utils import PasswordUtils
from database.db_operations import DBOperations

class UserManager:
    def __init__(self):
        self.db = DBOperations()
        self.pw_utils = PasswordUtils()
        self.logger = logging.getLogger('user_manager')

    def create_user(self, user_data: dict) -> tuple:
        """
        Buat user baru dengan password hash dan status aktif.
        """
        valid, msg = self.pw_utils.validate_password_policy(user_data['password'])
        if not valid:
            return False, msg

        hashed_pw = self.pw_utils.hash_password(user_data['password'])
        record = {
            'username': user_data['username'],
            'password_hash': hashed_pw,
            'role': user_data.get('role', 'viewer'),
            'is_active': 1  # default aktif
        }
        try:
            self.db.insert_data('users', record)
            return True, "✅ User berhasil dibuat"
        except Exception as e:
            self.logger.error(f"Gagal buat user: {e}")
            return False, f"Gagal buat user: {e}"

    def verify_login(self, username: str, password: str) -> tuple:
        """
        Verifikasi username dan password. 
        Return (True, user_dict) jika berhasil, (False, pesan_error) jika gagal.
        """
        try:
            # Query user berdasarkan username case-insensitive
            df = self.db.execute_raw_query(
                "SELECT * FROM users WHERE LOWER(username)=%s", (username.lower(),)
            )
            if df.empty:
                return False, "❌ Username tidak ditemukan"

            row = df.iloc[0]
            self.logger.debug(f"User row data: {row.to_dict()}")

            # Cek is_active dengan aman, default 1 (aktif)
            is_active = row.get('is_active', 1)
            if not is_active:
                return False, "❌ Akun tidak aktif"

            # Cek password
            if not self.pw_utils.verify_password(password, row['password_hash']):
                return False, "❌ Password salah"

            # Jika berhasil, kembalikan data user sebagai dict
            return True, dict(row)

        except Exception as e:
            self.logger.error(f"Login error: {e}")
            return False, f"❌ Error saat login: {e}"

    def verify_user_credentials(self, username: str, password: str) -> tuple:
        """
        Alias untuk verify_login agar konsisten.
        """
        return self.verify_login(username, password)
