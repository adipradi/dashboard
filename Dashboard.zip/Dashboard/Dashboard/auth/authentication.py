import streamlit as st
from auth.user_management import UserManager
from auth.session import SessionManager
from auth.audit_log import AuditLogger
from auth.rbac import RBAC
import logging
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

class AuthenticationSystem:
    """
    Sistem autentikasi lengkap dengan:
    - Login/Logout aman
    - Manajemen sesi
    - Logging aktivitas (audit)
    - Pembatasan brute-force
    - Kontrol akses berbasis peran
    """

    MAX_LOGIN_ATTEMPTS = 5
    LOGIN_TIMEOUT = 300  # dalam detik

    def __init__(self):
        self.user_manager = UserManager()
        self.session = SessionManager()
        self.audit = AuditLogger()
        self.login_attempts = {}  # {"ip_username": count}

    def render_login_form(self) -> None:
        st.title("🔐 System Authentication")
        client_ip = self._get_client_ip()

        if self._is_ip_blocked(client_ip):
            st.error("⚠️ Too many failed attempts. Please try again later.")
            return

        with st.form("secure_login_form", clear_on_submit=True):
            username = st.text_input("Username", placeholder="Enter your username", max_chars=50)
            password = st.text_input("Password", type="password", placeholder="••••••••", max_chars=100)
            remember_me = st.checkbox("Remember this device")

            if st.form_submit_button("Authenticate", type="primary"):
                self._handle_login_attempt(username, password, remember_me, client_ip)

    def _handle_login_attempt(self, username: str, password: str, remember_me: bool, client_ip: str) -> None:
        try:
            if self._check_login_rate(username, client_ip):
                raise ValueError("Too many attempts. Please wait.")

            success, result = self.user_manager.verify_user_credentials(username, password)

            if not success:
                raise ValueError(result)

            user_data = result

            if not user_data.get('is_active', True):
                raise ValueError("Account is temporarily deactivated")

            self.session.init_session(user_data, remember_me)
            self._reset_login_attempts(username, client_ip)

            self.audit.log_action(
                'LOGIN_SUCCESS',
                f'Successful login from IP {client_ip}',
                user_data['id'],
                metadata={
                    'ip': client_ip,
                    'user_agent': st.session_state.get('user_agent')
                }
            )

            st.toast(f"Authentication successful. Welcome {user_data['username']}!", icon="✅")
            time.sleep(1)
            st.rerun()

        except Exception as e:
            self._handle_login_failure(username, str(e), client_ip)
            st.error(f"Authentication failed: {str(e)}")

    def _handle_login_failure(self, username: str, error_msg: str, client_ip: str) -> None:
        self._increment_login_attempt(username, client_ip)

        self.audit.log_action(
            'LOGIN_FAILED',
            f'Failed login attempt: {error_msg}',
            status='failed',
            metadata={
                'username': username,
                'ip': client_ip,
                'error': error_msg
            }
        )

        logger.warning(f"Failed login attempt for {username} from {client_ip}: {error_msg}")

    def logout(self) -> None:
        if st.session_state.get('logged_in'):
            self.audit.log_action(
                'LOGOUT',
                'User logged out',
                st.session_state.get('user_id'),
                metadata={
                    'session_duration': self._get_session_duration()
                }
            )

        self.session.clear_session()
        st.success("You have been securely logged out.")
        time.sleep(1)
        st.rerun()

    def check_auth(self) -> bool:
        return self.session.validate_session()

    def require_auth(self):
        if not self.check_auth():
            self.render_login_form()
            st.stop()

    def role_required(self, *required_roles: str) -> None:
        if not self.check_auth():
            self.render_login_form()
            st.stop()

        user_role = st.session_state.get('role')
        if not RBAC.check_role_access(user_role, required_roles):
            self.audit.log_action(
                'UNAUTHORIZED_ACCESS',
                'Attempt to access restricted content',
                st.session_state.get('user_id'),
                status='failed'
            )
            st.error("🔒 Access Denied: Insufficient privileges")
            st.stop()

    # Helper

    def _get_client_ip(self) -> str:
        return st.session_state.get('client_ip', 'unknown')

    def _increment_login_attempt(self, username: str, ip: str) -> None:
        key = f"{ip}_{username}"
        self.login_attempts[key] = self.login_attempts.get(key, 0) + 1

    def _reset_login_attempts(self, username: str, ip: str) -> None:
        key = f"{ip}_{username}"
        self.login_attempts.pop(key, None)

    def _is_ip_blocked(self, ip: str) -> bool:
        return any(count >= self.MAX_LOGIN_ATTEMPTS for key, count in self.login_attempts.items() if ip in key)

    def _check_login_rate(self, username: str, ip: str) -> bool:
        key = f"{ip}_{username}"
        return self.login_attempts.get(key, 0) >= self.MAX_LOGIN_ATTEMPTS

    def _get_session_duration(self) -> str:
        login_time = st.session_state.get("login_time")
        if login_time:
            duration = datetime.now() - login_time
            return str(duration)
        return "unknown"
