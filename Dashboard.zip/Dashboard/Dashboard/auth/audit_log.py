# auth/audit_log.py
from database.db_operations import DBOperations
from datetime import datetime, timedelta
import streamlit as st
import logging
from typing import Optional, List, Dict, Any
import socket
import json
import os

class AuditLogger:
    """
    Enhanced audit logging system with:
    - Comprehensive activity tracking
    - Error resilience
    - IP address resolution
    - JSON metadata support
    - Optional file logging
    """

    def __init__(self, db: Optional[DBOperations] = None):
        """
        Initialize the audit logger
        
        Args:
            db: Database operations instance (optional)
        """
        self.db = db or DBOperations()
        self._init_audit_table()
        self.logger = logging.getLogger('audit_log')
        self.logger.setLevel(logging.INFO)

        # Optional: log to file (logs/audit.log)
        os.makedirs("logs", exist_ok=True)
        file_handler = logging.FileHandler("logs/audit.log")
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)

    def _init_audit_table(self) -> None:
        """Initialize the audit logs table with enhanced schema"""
        if not self.db.table_exists('audit_logs'):
            self.db.execute_query("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    username VARCHAR(100),
                    action_type VARCHAR(50) NOT NULL,
                    details TEXT,
                    metadata TEXT,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    status VARCHAR(20),
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    INDEX user_idx (user_id),
                    INDEX action_idx (action_type),
                    INDEX time_idx (timestamp)
                )
            """)

    def _get_client_ip(self) -> str:
        """Get client IP address with fallback"""
        try:
            return st.session_state.get('client_ip') or \
                   socket.gethostbyname(socket.gethostname())
        except:
            return "unknown"

    def log_action(
        self,
        action_type: str,
        details: str,
        user_id: Optional[int] = None,
        metadata: Optional[Dict] = None,
        status: str = "success"
    ) -> None:
        """
        Log a user action with comprehensive tracking
        
        Args:
            action_type: Type of action (e.g., 'LOGIN', 'DATA_ACCESS')
            details: Description of the action
            user_id: ID of the user performing the action
            metadata: Additional structured data
            status: Action status ('success', 'failed', 'warning')
        """
        try:
            log_data = {
                'user_id': user_id or st.session_state.get('user_id', 0),
                'username': st.session_state.get('username', 'anonymous'),
                'action_type': action_type[:50],
                'details': details[:2000],  # Safe truncation
                'metadata': json.dumps(metadata) if metadata else None,
                'ip_address': self._get_client_ip(),
                'user_agent': st.session_state.get('user_agent', 'unknown'),
                'status': status[:20],
                'timestamp': datetime.now()
            }

            self.db.add_record('audit_logs', log_data)
            self.logger.info(
                f"Action logged: {action_type} by user {log_data['user_id']}"
            )

        except Exception as e:
            self.logger.error(f"Failed to log action: {str(e)}", exc_info=True)
            print(f"[AUDIT FAILURE] {action_type}: {details}")

    def get_user_logs(
        self,
        user_id: int,
        limit: int = 50,
        action_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve user activity logs with filtering
        
        Args:
            user_id: ID of the user
            limit: Maximum number of records to return
            action_filter: Optional action type filter
            
        Returns:
            List of audit log records as dictionaries
        """
        try:
            filters = {'user_id': user_id}
            if action_filter:
                filters['action_type'] = action_filter

            logs = self.db.get_data(
                'audit_logs',
                filters=filters,
                order_by='timestamp DESC',
                limit=limit
            )

            # Safe load metadata JSON
            def safe_json_load(x):
                try:
                    return json.loads(x) if x else {}
                except json.JSONDecodeError:
                    return {}

            if not logs.empty and 'metadata' in logs.columns:
                logs['metadata'] = logs['metadata'].apply(safe_json_load)

            return logs.to_dict('records')

        except Exception as e:
            self.logger.error(
                f"Failed to retrieve logs for user {user_id}: {str(e)}",
                exc_info=True
            )
            return []

    def get_recent_actions(self, hours: int = 24) -> List[Dict[str, Any]]:
        """
        Get all actions within specified time window
        
        Args:
            hours: Hours to look back
            
        Returns:
            List of recent audit records
        """
        try:
            time_threshold = datetime.now() - timedelta(hours=hours)
            logs = self.db.get_data(
                'audit_logs',
                filters={'timestamp': ('>', time_threshold)},
                order_by='timestamp DESC'
            )

            return logs.to_dict('records')
        except Exception as e:
            self.logger.error(
                f"Failed to get recent actions: {str(e)}",
                exc_info=True
            )
            return []

# Example usage
if __name__ == "__main__":
    logger = AuditLogger()

    logger.log_action(
        action_type="TEST",
        details="Testing audit system",
        user_id=0,
        metadata={"test": True},
        status="success"
    )

    logs = logger.get_user_logs(user_id=0)
    print("Sample logs:", logs)
