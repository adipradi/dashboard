# auth/password_utils.py
import re
import secrets
import string
from typing import Tuple

# Common passwords to reject (partial list)
COMMON_PASSWORDS = {
    'password', '123456', '12345678', '123456789', 'qwerty',
    'abc123', 'password1', 'admin', 'welcome', 'letmein'
}


class PasswordUtils:
    """
    Password utility class with:
    - Strong password generation
    - Comprehensive policy validation
    """

    def __init__(self, policy=None):
        self.policy = policy or {
            'min_length': 12,
            'max_length': 512,
            'require_upper': True,
            'require_lower': True,
            'require_digit': True,
            'require_special': True,
            'special_chars': "!@#$%^&*(),.?\":{}|<>_-",
            'max_repeats': 3,
            'max_sequential': 3
        }

    def verify_password(self, input_password: str, stored_password: str) -> bool:
        """
        Verifikasi password secara langsung (plaintext comparison).
        PENTING: Ini tidak aman untuk produksi.
        """
        return input_password == stored_password

    def validate_password_policy(self, password: str) -> Tuple[bool, str]:
        """Comprehensive password policy validation."""
        if not isinstance(password, str):
            return False, "Password must be a string"

        # Length checks
        if len(password) < self.policy['min_length']:
            return False, f"Minimum {self.policy['min_length']} characters required"
        if len(password) > self.policy['max_length']:
            return False, f"Maximum {self.policy['max_length']} characters allowed"

        # Character diversity checks
        checks = [
            (self.policy['require_upper'] and not re.search(r"[A-Z]", password),
             "Must contain uppercase letters"),
            (self.policy['require_lower'] and not re.search(r"[a-z]", password),
             "Must contain lowercase letters"),
            (self.policy['require_digit'] and not re.search(r"[0-9]", password),
             "Must contain digits"),
            (self.policy['require_special'] and not re.search(
                r"[{}]".format(re.escape(self.policy['special_chars'])), password),
             f"Must contain special characters: {self.policy['special_chars']}"),
        ]

        for condition, message in checks:
            if condition:
                return False, message

        # Pattern checks
        lower_pass = password.lower()
        if lower_pass in COMMON_PASSWORDS or any(common in lower_pass for common in COMMON_PASSWORDS):
            return False, "Password is too common"

        if self._has_repeating_chars(password):
            return False, "Password contains too many repeating characters"

        if self._has_sequential_chars(password):
            return False, "Password contains obvious sequential patterns"

        return True, "Password meets all requirements"

    def _has_repeating_chars(self, password: str) -> bool:
        """Check for excessive repeating characters."""
        max_repeats = self.policy.get('max_repeats', 3)
        return bool(re.search(r"(.)\1{%d,}" % (max_repeats - 1), password))

    def _has_sequential_chars(self, password: str) -> bool:
        """Check for sequential characters (123, abc, etc.)."""
        max_seq = self.policy.get('max_sequential', 3)
        lower = password.lower()
        for i in range(len(lower) - max_seq + 1):
            segment = lower[i:i + max_seq]
            if (segment in string.ascii_lowercase or
                    segment in string.digits or
                    segment in self.policy['special_chars']):
                return True
        return False

    def generate_strong_password(self, length: int = 16) -> str:
        """Generate a cryptographically strong random password."""
        if length < self.policy['min_length']:
            raise ValueError(f"Minimum length is {self.policy['min_length']}")
        if length > self.policy['max_length']:
            raise ValueError(f"Maximum length is {self.policy['max_length']}")

        alphabet = (
            string.ascii_letters +
            string.digits +
            self.policy['special_chars']
        )

        while True:
            password = ''.join(secrets.choice(alphabet) for _ in range(length))
            valid, _ = self.validate_password_policy(password)
            if valid:
                return password


if __name__ == "__main__":
    utils = PasswordUtils()

    print("=== Testing Password Generation ===")
    for _ in range(3):
        pwd = utils.generate_strong_password()
        print(f"Generated: {pwd} | Valid: {utils.validate_password_policy(pwd)}")

    print("\n=== Testing Password Verification ===")
    stored_pw = "StrongPass!123"
    print(utils.verify_password("StrongPass!123", stored_pw))  # True
    print(utils.verify_password("wrongpass", stored_pw))       # False

    print("\n=== Testing Weak Passwords ===")
    tests = [
        "password", "1234567890", "Admin123",
        "SecurePwd!!", "Aa1!Aa1!Aa1!", "ABC123!!"
    ]
    for pwd in tests:
        valid, reason = utils.validate_password_policy(pwd)
        print(f"{pwd:<15} | {str(valid):<5} | {reason}")
