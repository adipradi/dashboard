# auth/session.py
import streamlit as st
from datetime import datetime, timedelta
import secrets
import logging
from typing import Dict, Optional
import hashlib

class SessionManager:
    def __init__(self, timeout_minutes: int = 30, remember_me_days: int = 30):
        """
        Enhanced session management with:
        - Separate timeout for normal and remember-me sessions
        - Secure session token generation
        - CSRF protection
        - Session fingerprinting
        - Detailed logging
        """
        self.normal_timeout = timedelta(minutes=timeout_minutes)
        self.remember_me_timeout = timedelta(days=remember_me_days)
        self._configure_logging()

    def _configure_logging(self):
        """Configure session logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('session_manager')

    def _generate_session_token(self) -> str:
        """Generate cryptographically secure session token"""
        return secrets.token_urlsafe(64)

    def _generate_csrf_token(self) -> str:
        """Generate CSRF protection token"""
        return secrets.token_urlsafe(64)

    def _get_client_fingerprint(self) -> str:
        """
        Create basic client fingerprint for session validation
        using user_agent string stored in session_state.
        """
        user_agent = st.session_state.get('user_agent', 'unknown')
        return hashlib.sha256(user_agent.encode()).hexdigest()

    def init_session(self, user_data: Dict, remember_me: bool = False) -> None:
        """Initialize authenticated session with enhanced security"""
        if not user_data.get('id') or not user_data.get('username'):
            raise ValueError("User data must contain 'id' and 'username'")

        # Ambil user_agent dan client_ip dari session_state jika ada, fallback ke 'unknown'
        user_agent = st.session_state.get('user_agent', 'unknown')
        client_ip = st.session_state.get('client_ip', 'unknown')

        session_data = {
            'authenticated': True,
            'user_id': user_data['id'],
            'username': user_data['username'],
            'role': user_data.get('role', 'user'),
            'login_time': datetime.now(),
            'last_activity': datetime.now(),
            'session_token': self._generate_session_token(),
            'csrf_token': self._generate_csrf_token(),
            'client_fingerprint': hashlib.sha256(user_agent.encode()).hexdigest(),
            'remember_me': remember_me,
            'ip_address': client_ip
        }

        st.session_state.update(session_data)
        self.logger.info(f"Session initialized for user: {user_data['username']}")

    def validate_session(self) -> bool:
        """Validate session with comprehensive checks"""
        if not st.session_state.get('authenticated'):
            self.logger.warning("Session validation failed: Not authenticated")
            return False

        # Check session timeout
        timeout = self.remember_me_timeout if st.session_state.get('remember_me') else self.normal_timeout
        if datetime.now() - st.session_state['last_activity'] > timeout:
            self.logger.info("Session expired due to inactivity")
            self.clear_session()
            return False

        # Verify session token exists
        if not st.session_state.get('session_token'):
            self.logger.warning("Session validation failed: Missing token")
            self.clear_session()
            return False

        # Basic client fingerprint validation
        current_fingerprint = self._get_client_fingerprint()
        if current_fingerprint != st.session_state.get('client_fingerprint'):
            self.logger.warning("Session validation failed: Fingerprint mismatch")
            self.clear_session()
            return False

        # Update last activity timestamp
        st.session_state['last_activity'] = datetime.now()
        return True

    def get_csrf_token(self) -> Optional[str]:
        """Retrieve current CSRF token"""
        if self.validate_session():
            return st.session_state.get('csrf_token')
        return None

    def verify_csrf_token(self, token: str) -> bool:
        """Verify CSRF token"""
        if not self.validate_session():
            return False
        return secrets.compare_digest(token, st.session_state.get('csrf_token', ''))

    def clear_session(self) -> None:
        """Securely clear session data"""
        username = st.session_state.get('username', 'unknown')
        keys = list(st.session_state.keys())

        for key in keys:
            del st.session_state[key]

        self.logger.info(f"Session cleared for user: {username}")

    def get_user_info(self) -> Optional[Dict]:
        """Get current user info if session is valid"""
        if self.validate_session():
            return {
                'user_id': st.session_state.get('user_id'),
                'username': st.session_state.get('username'),
                'role': st.session_state.get('role')
            }
        return None
