import streamlit as st
from modules.youtube_analytics import YouTubeAPI, YouTubeVisualizer
from auth.authentication import AuthenticationSystem
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('youtube_analytics')

def initialize_session():
    """Initialize and authenticate session"""
    try:
        auth = AuthenticationSystem()
        auth.require_auth()
        return True
    except Exception as e:
        logger.error(f"Authentication failed: {e}")
        st.error("Failed to authenticate. Please try again.")
        return False

def main():
    # Page configuration
    st.set_page_config(
        page_title="YouTube Analytics Dashboard",
        page_icon="📺",
        layout="wide"
    )

    # Initialize session
    if not initialize_session():
        st.stop()

    # Initialize YouTube components
    try:
        yt_api = YouTubeAPI()
        yt_viz = YouTubeVisualizer(yt_api)
    except Exception as e:
        logger.error(f"YouTube initialization failed: {e}")
        st.error("Failed to initialize YouTube analytics. Please try again later.")
        st.stop()

    # UI Header
    st.title("📺 YouTube Analytics Dashboard")
    st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Sidebar for additional controls
    with st.sidebar:
        st.header("🔍 Settings")
        time_range = st.selectbox(
            "Time Range",
            ["Last 7 days", "Last 30 days", "Last 90 days", "Last year"],
            index=1
        )
        max_videos = st.slider(
            "Max Videos to Analyze",
            min_value=5,
            max_value=50,
            value=15
        )
        st.markdown("---")
        st.markdown("**Help:**")
        st.markdown("Find Channel ID in YouTube Studio → Settings → Advanced")

    # Channel ID input with examples
    col1, col2 = st.columns([3, 1])
    with col1:
        channel_id = st.text_input(
            "Enter YouTube Channel ID",
            placeholder="UC_x5XG1OV2P6uZZ5FSM9Ttw",
            help="Example: UC_x5XG1OV2P6uZZ5FSM9Ttw (Google Developers)"
        )
    with col2:
        st.markdown("### Popular Channels:")
        if st.button("Google Developers"):
            st.session_state.channel_id = "UC_x5XG1OV2P6uZZ5FSM9Ttw"
            st.rerun()
        if st.button("TED"):
            st.session_state.channel_id = "UCsooa4yRKGN_zEE8iknghZA"
            st.rerun()

    # Use session state to persist channel ID
    if 'channel_id' not in st.session_state:
        st.session_state.channel_id = channel_id
    else:
        if channel_id != st.session_state.channel_id:
            st.session_state.channel_id = channel_id
            st.rerun()

    # Main tabs
    tab1, tab2, tab3 = st.tabs(["📊 Channel Overview", "🎥 Video Analytics", "📈 Trends"])

    if st.session_state.channel_id:
        try:
            with st.spinner("Loading YouTube data..."):
                with tab1:
                    yt_viz.show_channel_overview(st.session_state.channel_id)

                with tab2:
                    yt_viz.show_video_performance(
                        st.session_state.channel_id,
                        max_results=max_videos,
                        time_range=time_range
                    )

                with tab3:
                    yt_viz.show_trending_analysis()
                    yt_viz.show_growth_trends(st.session_state.channel_id)

        except Exception as e:
            logger.error(f"Error loading YouTube data: {e}")
            st.error("Failed to load channel data. Please check the Channel ID and try again.")
    else:
        st.info("ℹ️ Please enter a YouTube Channel ID to begin analysis")

if __name__ == "__main__":
    main()
