import streamlit as st
from datetime import datetime
from modules.chatbot import ChatUI, ChatProcessor, ChatHistory
from database.db_operations import DBOperations
from auth.authentication import AuthenticationSystem
import logging
from typing import Optional, Dict

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('chatbot_app')

def initialize_session() -> bool:
    """Initialize chat session and return True if successful"""
    try:
        if 'user_id' not in st.session_state:
            st.error("Session tidak valid. Silakan login ulang.")
            return False

        if 'chat_ready' not in st.session_state:
            st.session_state.chat_ready = True
            history.clear_history(st.session_state.user_id)
            st.session_state.messages_processed = 0
            st.session_state.start_time = datetime.now()
            logger.info(f"New chat session started for user {st.session_state.user_id}")
        return True
    except Exception as e:
        logger.error(f"Session initialization failed: {e}")
        return False

def handle_user_message(prompt: str) -> Optional[Dict]:
    """Process user message and return assistant response"""
    try:
        history.save_message(st.session_state.user_id, {
            "role": "user",
            "content": prompt,
            "timestamp": datetime.now()
        })
        st.session_state.messages_processed += 1

        with st.spinner("Menganalisis permintaan Anda..."):
            response = processor.generate_response(
                user_id=st.session_state.user_id,
                prompt=prompt,
                conversation_context=history.get_history(
                    st.session_state.user_id, 
                    limit=5
                )
            )

        if response and 'content' in response:
            history.save_message(st.session_state.user_id, {
                "role": "assistant",
                "content": response['content'],
                "metadata": response.get('metadata', {}),
                "timestamp": datetime.now()
            })
            return response
        else:
            st.warning("Asisten tidak dapat memberikan jawaban saat ini.")
    
    except Exception as e:
        logger.error(f"Error processing message: {e}")
        st.error("Terjadi kesalahan saat memproses permintaan Anda")
    return None

def display_chat_stats():
    """Display chat statistics in sidebar"""
    if 'messages_processed' in st.session_state:
        session_duration = (datetime.now() - st.session_state.start_time).seconds // 60
        st.sidebar.markdown(f"""
        **📊 Statistik Sesi**
        - Pesan diproses: {st.session_state.messages_processed}
        - Durasi sesi: {session_duration} menit
        """)

def main():
    try:
        global auth, db, processor, history, chat_ui

        auth = AuthenticationSystem()
        auth.require_auth()
        db = DBOperations()

        processor = ChatProcessor(db)
        history = ChatHistory(db)
        chat_ui = ChatUI(processor, history)

    except Exception as e:
        logger.critical(f"Application initialization failed: {e}")
        st.error("Gagal memulai aplikasi. Silakan coba lagi atau hubungi administrator.")
        st.stop()

    st.set_page_config(
        page_title="AI Analytics Assistant",
        page_icon="🤖",
        layout="wide"
    )

    st.title("🤖 AI Analytics Assistant")
    st.caption("Tanyakan apapun tentang data Anda - Dapatkan wawasan instan")

    if not initialize_session():
        st.stop()

    with st.sidebar:
        st.header("Pengaturan")
        if st.button("🔄 Mulai Sesi Baru"):
            history.clear_history(st.session_state.user_id)
            st.session_state.messages_processed = 0
            st.session_state.start_time = datetime.now()
            st.rerun()

        display_chat_stats()

        st.markdown("---")
        st.markdown("**Fitur:**")
        st.markdown("- Analisis data otomatis")
        st.markdown("- Visualisasi interaktif")
        st.markdown("- Dukungan multi-bahasa")

    col1, col2 = st.columns([3, 1])

    with col1:
        chat_ui.display_chat_history(st.session_state.user_id)

        prompt = st.chat_input(
            "Ketik pesan Anda...",
            key="chat_input",
            on_submit=lambda: st.rerun()
        )

        if prompt:
            response = handle_user_message(prompt)
            if response:
                st.rerun()

    with col2:
        st.header("Contoh Pertanyaan")
        examples = [
            "Tampilkan trend penjualan 3 bulan terakhir",
            "Bandingkan performa produk A dan B",
            "Buat visualisasi untuk distribusi pelanggan",
            "Apa insight utama dari data Q3?"
        ]
        for example in examples:
            if st.button(example, use_container_width=True):
                st.session_state.chat_input = example
                st.rerun()

    st.markdown("---")
    st.markdown("© 2025 AI Analytics Assistant | Dibangun dengan ❤️ dan Streamlit")

if __name__ == "__main__":
    main()
