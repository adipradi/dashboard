import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from modules.web_analytics import WebTracker, WebVisualizer
from database.db_operations import DBOperations
from auth.authentication import AuthenticationSystem
import pandas as pd
import logging
from typing import Dict

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('web_analytics')

# Initialize authentication and database
try:
    auth = AuthenticationSystem()
    auth.require_auth()
    db = DBOperations()
    tracker = WebTracker(db)
    visualizer = WebVisualizer(db)
    tracker.track_pageview("Web Analytics Dashboard")
except Exception as e:
    logger.error(f"Initialization failed: {e}")
    st.error("Failed to initialize application. Please try again later.")
    st.stop()

# Page configuration
st.set_page_config(
    page_title="Web Analytics Dashboard",
    page_icon="🌐",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .metric-card {
        padding: 15px;
        border-radius: 10px;
        background-color: #f8f9fa;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .metric-title {
        font-size: 14px;
        color: #6c757d;
        margin-bottom: 5px;
    }
    .metric-value {
        font-size: 24px;
        font-weight: bold;
    }
    .positive { color: #28a745; }
    .negative { color: #dc3545; }
</style>
""", unsafe_allow_html=True)

def get_time_period_data(hours: int = 24) -> Dict[str, pd.DataFrame]:
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=hours)
    return {
        'page_views': db.get_data('page_views', filters={'timestamp': (start_time, end_time)}),
        'events': db.get_data('events', filters={'timestamp': (start_time, end_time)}),
        'traffic_sources': db.get_data('traffic_sources'),
        'user_tech': db.get_data('user_tech')
    }

def display_traffic_metrics(data: Dict[str, pd.DataFrame]):
    st.subheader("🚦 Traffic Overview")
    page_views = data['page_views']
    unique_visitors = page_views['client_id'].nunique() if 'client_id' in page_views else 0
    total_views = len(page_views)
    avg_session = tracker._calculate_avg_session_duration(page_views)
    bounce_rate = tracker._calculate_bounce_rate(page_views)
    cols = st.columns(4)
    with cols[0]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">👥 Unique Visitors</div>
            <div class="metric-value">{unique_visitors:,}</div>
        </div>""", unsafe_allow_html=True)
    with cols[1]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">📄 Pageviews</div>
            <div class="metric-value">{total_views:,}</div>
        </div>""", unsafe_allow_html=True)
    with cols[2]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">⏱ Avg. Session</div>
            <div class="metric-value">{avg_session:.1f}s</div>
        </div>""", unsafe_allow_html=True)
    with cols[3]:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-title">↩️ Bounce Rate</div>
            <div class="metric-value">{bounce_rate:.1f}%</div>
        </div>""", unsafe_allow_html=True)

def plot_traffic_sources(data: pd.DataFrame):
    st.subheader("🔗 Traffic Sources")
    if not data.empty:
        cols = st.columns(2)
        with cols[0]:
            fig = px.pie(data, names='source', values='count', title='Traffic Source Distribution', hole=0.3)
            st.plotly_chart(fig, use_container_width=True)
        with cols[1]:
            fig = px.bar(data.sort_values('count', ascending=False), x='source', y='count', title='Top Traffic Sources')
            st.plotly_chart(fig, use_container_width=True)

def plot_user_behavior(data: Dict[str, pd.DataFrame]):
    st.subheader("🧽 User Behavior")
    page_views = data['page_views']
    if not page_views.empty:
        top_pages = page_views['page_url'].value_counts().head(10).reset_index()
        top_pages.columns = ['page_url', 'count']
        fig = px.bar(top_pages, x='page_url', y='count', title='Top 10 Pages by Views')
        st.plotly_chart(fig, use_container_width=True)
    st.subheader("🔄 User Flow")
    fig = go.Figure(go.Sankey(
        node=dict(pad=15, thickness=20, line=dict(color="black", width=0.5),
                  label=["Home", "Products", "Cart", "Checkout", "Purchase"]),
        link=dict(source=[0, 0, 1, 1, 2], target=[1, 2, 2, 3, 3], value=[100, 50, 30, 20, 10])
    ))
    st.plotly_chart(fig, use_container_width=True)

def plot_technical_analysis(data: pd.DataFrame):
    st.subheader("💻 Technical Analysis")
    if not data.empty:
        cols = st.columns(2)
        with cols[0]:
            fig = px.bar(data, x='browser', y='users', color='os', title='Browser and OS Usage')
            st.plotly_chart(fig, use_container_width=True)
        with cols[1]:
            device_data = data.groupby('device_type')['users'].sum().reset_index()
            fig = px.pie(device_data, names='device_type', values='users', title='Device Type Distribution', hole=0.3)
            st.plotly_chart(fig, use_container_width=True)

def main():
    st.title("🌐 Web Analytics Dashboard")
    st.write(f"Data real-time diperbarui setiap 5 menit - Terakhir diupdate: {datetime.now().strftime('%H:%M:%S')}")
    with st.sidebar:
        st.header("🔍 Filters")
        time_period = st.select_slider("Time Period", options=['1h', '6h', '12h', '24h', '7d'], value='24h')
        time_map = {'1h': 1, '6h': 6, '12h': 12, '24h': 24, '7d': 168}
        hours = time_map[time_period]
    with st.spinner("Loading data..."):
        data = get_time_period_data(hours)
    tab1, tab2, tab3 = st.tabs(["Traffic", "Behavior", "Technical"])
    with tab1:
        display_traffic_metrics(data)
        plot_traffic_sources(data['traffic_sources'])
        visualizer.show_realtime_metrics(hours)
    with tab2:
        plot_user_behavior(data)
        st.subheader("🎯 User Events")
        events_df = data['events']
        if not events_df.empty:
            event_counts = events_df['event_name'].value_counts().reset_index()
            event_counts.columns = ['event_name', 'count']
            fig = px.bar(event_counts, x='event_name', y='count', title='Most Frequent User Events')
            st.plotly_chart(fig, use_container_width=True)
    with tab3:
        plot_technical_analysis(data['user_tech'])
        st.subheader("⚡ Performance Metrics")
        performance_data = db.get_data('performance_metrics')
        if not performance_data.empty:
            fig = px.line(performance_data, x='timestamp',
                          y=['page_load_time', 'api_response_time'],
                          title='Performance Over Time',
                          labels={'value': 'Time (ms)', 'timestamp': 'Time'})
            st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()
