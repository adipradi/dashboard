import streamlit as st
from datetime import datetime
from database.db_operations import DBOperations
from modules.chatbot.chat_history import ChatHistory

st.title("Test Session Init")

db = DBOperations()
history = ChatHistory(db)

if 'user_id' not in st.session_state:
    st.session_state.user_id = "test_user"  # Simulasi login

if st.button("Inisialisasi"):
    history.clear_history(st.session_state.user_id)
    st.success("Berhasil clear history")
