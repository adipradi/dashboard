import mysql.connector
from mysql.connector import Error
from contextlib import contextmanager
import os

class DBConnection:
    def __init__(self):
        self.config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'user': os.getenv('DB_USER', 'admin'),
            'password': os.getenv('DB_PASSWORD', '123456'),
            'database': os.getenv('DB_NAME', 'dashboard_db'),
            'port': int(os.getenv('DB_PORT', 3306))
        }

    @contextmanager
    def get_cursor(self):
        conn = mysql.connector.connect(**self.config)
        try:
            cursor = conn.cursor(dictionary=True)
            yield cursor
            conn.commit()
        except Error as e:
            conn.rollback()
            raise e
        finally:
            cursor.close()
            conn.close()
