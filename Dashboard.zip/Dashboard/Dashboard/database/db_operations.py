import pandas as pd
import logging
import re
from datetime import datetime
from typing import Optional, Dict, List, Union, Tuple

import streamlit as st
from database.db_connection import DBConnection


class DBOperations:
    def __init__(self):
        self.db = DBConnection()
        self._configure_logging()

    def _configure_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('db_operations')

    def _sanitize_table_name(self, table_name: str) -> str:
        if not re.match(r'^[a-zA-Z0-9_]+$', table_name):
            raise ValueError("Invalid table name")
        return table_name

    def _validate_input_data(self, data: Dict, required_fields: List[str]) -> bool:
        return all(field in data for field in required_fields)

    def get_produk(self, filter_kategori: Optional[str] = None) -> pd.DataFrame:
        try:
            query = "SELECT id, nama, kategori, harga, stok, deskripsi FROM produk"
            params = []
            if filter_kategori:
                query += " WHERE kategori = %s"
                params.append(filter_kategori)
            with self.db.get_cursor() as cursor:
                cursor.execute(query, tuple(params))
                rows = cursor.fetchall()
                return pd.DataFrame(rows) if rows else pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Error getting products: {e}")
            st.error("❌ Gagal memuat data produk")
            raise

    def update_stok(self, produk_id: int, qty: int) -> bool:
        try:
            with self.db.get_cursor() as cursor:
                cursor.execute("UPDATE produk SET stok = stok + %s WHERE id = %s", (qty, produk_id))
                return cursor.rowcount > 0
        except Exception as e:
            self.logger.error(f"Error updating stock: {e}")
            st.error("❌ Gagal memperbarui stok")
            raise

    def add_pelanggan(self, data: Dict) -> Tuple[bool, Union[int, str]]:
        try:
            if not self._validate_input_data(data, ['nama', 'email', 'telp', 'alamat']):
                return False, "⚠️ Data pelanggan tidak lengkap"
            with self.db.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO pelanggan (nama, email, telp, alamat, tier)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    data['nama'], data['email'], data['telp'],
                    data['alamat'], data.get('tier', 'Regular')
                ))
                return True, cursor.lastrowid
        except Exception as e:
            self.logger.error(f"Error adding customer: {e}")
            return False, f"Gagal menambahkan pelanggan: {e}"

    def get_pelanggan(self, pelanggan_id: Optional[int] = None) -> pd.DataFrame:
        try:
            query = "SELECT id, nama, email, telp, alamat, tier FROM pelanggan"
            params = []
            if pelanggan_id:
                query += " WHERE id = %s"
                params.append(pelanggan_id)
            with self.db.get_cursor() as cursor:
                cursor.execute(query, tuple(params))
                rows = cursor.fetchall()
                return pd.DataFrame(rows) if rows else pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Error getting customers: {e}")
            st.error("❌ Gagal memuat data pelanggan")
            raise

    def record_penjualan(self, data: Dict) -> Tuple[bool, Union[int, str]]:
        required = ['invoice_id', 'tanggal', 'produk_id', 'qty', 'harga_satuan', 'total']
        if not self._validate_input_data(data, required):
            return False, "⚠️ Data penjualan tidak lengkap"

        try:
            with self.db.get_cursor() as cursor:
                cursor.connection.autocommit(False)

                cursor.execute("""
                    INSERT INTO penjualan
                    (invoice_id, tanggal, pelanggan_id, produk_id, qty, harga_satuan, diskon, total, metode_bayar)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    data['invoice_id'], data['tanggal'], data.get('pelanggan_id'),
                    data['produk_id'], data['qty'], data['harga_satuan'],
                    data.get('diskon', 0), data['total'], data.get('metode_bayar', 'Tunai')
                ))

                if not self.update_stok(data['produk_id'], -data['qty']):
                    cursor.execute("ROLLBACK")
                    return False, "❌ Gagal memperbarui stok"

                cursor.execute("COMMIT")
                return True, cursor.lastrowid

        except Exception as e:
            if 'cursor' in locals():
                cursor.execute("ROLLBACK")
            self.logger.error(f"Error recording sale: {e}")
            return False, f"Gagal mencatat penjualan: {e}"

    def get_data(self, table_name: str,
                 filters: Optional[Dict] = None,
                 date_range: Optional[Tuple[datetime, datetime]] = None,
                 columns: Optional[List[str]] = None,
                 limit: Optional[int] = None) -> pd.DataFrame:
        try:
            table_name = self._sanitize_table_name(table_name)
            select_cols = "*" if not columns else ", ".join(columns)
            query = f"SELECT {select_cols} FROM {table_name}"
            params = []
            conditions = []

            if filters:
                for k, v in filters.items():
                    conditions.append(f"{k} = %s")
                    params.append(v)

            if date_range:
                conditions.append("tanggal BETWEEN %s AND %s")
                params.extend([date_range[0], date_range[1]])

            if conditions:
                query += " WHERE " + " AND ".join(conditions)

            if limit is not None:
                query += f" LIMIT {limit}"

            with self.db.get_cursor() as cursor:
                cursor.execute(query, tuple(params))
                rows = cursor.fetchall()
                return pd.DataFrame(rows) if rows else pd.DataFrame()

        except Exception as e:
            self.logger.error(f"Error querying {table_name}: {e}")
            st.error(f"❌ Gagal memuat data dari {table_name}")
            raise

    def execute_raw_query(self, query: str, params: Optional[Tuple] = None) -> pd.DataFrame:
        try:
            with self.db.get_cursor() as cursor:
                self.logger.debug(f"Executing raw query: {query} | Params: {params}")
                cursor.execute(query, tuple(params) if params else ())
                if query.strip().upper().startswith("SELECT"):
                    rows = cursor.fetchall()
                    return pd.DataFrame(rows) if rows else pd.DataFrame()
                return pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Raw query error: {query} - {e}")
            st.error("❌ Gagal menjalankan query mentah")
            raise

    def table_exists(self, table_name: str) -> bool:
        try:
            query = """
                SELECT COUNT(*) FROM information_schema.tables
                WHERE table_schema = %s AND table_name = %s
            """
            db_name = self.db.config.get("database", "your_db_name")
            with self.db.get_cursor() as cursor:
                cursor.execute(query, (db_name, table_name))
                result = cursor.fetchone()
                return result[0] > 0
        except Exception as e:
            self.logger.error(f"Error checking table existence: {e}")
            return False

    def execute_query(self, query: str, params: Optional[Tuple] = None) -> None:
        try:
            with self.db.get_cursor() as cursor:
                cursor.execute(query, tuple(params) if params else ())
        except Exception as e:
            self.logger.error(f"Error executing query: {query} - {e}")
            raise

    def add_record(self, table_name: str, data: Dict[str, Union[str, int, float, None]]) -> bool:
        """
        Menambahkan satu record ke tabel tertentu.
        """
        try:
            table_name = self._sanitize_table_name(table_name)
            if not data:
                raise ValueError("Data kosong")

            columns = ', '.join(data.keys())
            placeholders = ', '.join(['%s'] * len(data))
            values = tuple(data.values())

            query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            with self.db.get_cursor() as cursor:
                cursor.execute(query, values)
                return True

        except Exception as e:
            self.logger.error(f"Error adding record to {table_name}: {e}")
            st.error(f"❌ Gagal menambahkan data ke tabel {table_name}")
            return False
