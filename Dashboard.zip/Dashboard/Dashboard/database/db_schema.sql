-- TABEL PRODUK
CREATE TABLE IF NOT EXISTS produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    kategori ENUM('Elektronik', 'Fashion', 'Makanan', 'Lainnya') NOT NULL,
    harga DECIMAL(12,2) NOT NULL,
    stok INT DEFAULT 0,
    deskripsi TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- TABEL PELANGGAN
CREATE TABLE IF NOT EXISTS pelanggan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    telp VARCHAR(20),
    alamat TEXT,
    tier ENUM('Regular', 'Silver', 'Gold') DEFAULT 'Regular',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TABEL PENJUALAN
CREATE TABLE IF NOT EXISTS penjualan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id VARCHAR(20) UNIQUE NOT NULL,
    tanggal DATETIME NOT NULL,
    pelanggan_id INT,
    produk_id INT NOT NULL,
    qty INT NOT NULL,
    harga_satuan DECIMAL(12,2) NOT NULL,
    diskon DECIMAL(5,2) DEFAULT 0,
    total DECIMAL(12,2) NOT NULL,
    metode_bayar ENUM('Tunai', 'Kartu Kredit', 'Transfer', 'Lainnya'),
    FOREIGN KEY (produk_id) REFERENCES produk(id),
    FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id)
);

-- TABEL BARANG REJECT
CREATE TABLE IF NOT EXISTS barang_reject (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produk_id INT NOT NULL,
    batch_number VARCHAR(50),
    alasan ENUM('Rusak', 'Kadaluarsa', 'Tidak Sesuai Spesifikasi', 'Lainnya') NOT NULL,
    qty INT NOT NULL,
    catatan TEXT,
    status ENUM('Pending', 'Diterima', 'Ditolak') DEFAULT 'Pending',
    created_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (produk_id) REFERENCES produk(id)
);

-- TABEL USERS
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff', 'viewer') NOT NULL,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TABEL PAGE VIEWS
CREATE TABLE IF NOT EXISTS page_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(36),
    client_id VARCHAR(36) NOT NULL,
    page_url VARCHAR(255) NOT NULL,
    timestamp DATETIME NOT NULL,
    user_id VARCHAR(36),
    ip_address VARCHAR(45),
    device_type ENUM('desktop', 'mobile', 'tablet', 'other'),
    browser VARCHAR(50),
    os VARCHAR(50),
    is_mobile BOOLEAN,
    INDEX (client_id),
    INDEX (timestamp)
);

-- TABEL EVENTS (metadata TEXT agar aman untuk MariaDB)
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(36),
    client_id VARCHAR(36) NOT NULL,
    event_name VARCHAR(100) NOT NULL,
    timestamp DATETIME NOT NULL,
    metadata TEXT,
    INDEX (client_id),
    INDEX (event_name)
);

-- TABEL CHAT HISTORY
CREATE TABLE IF NOT EXISTS chat_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    conversation_id VARCHAR(100) NOT NULL,
    role ENUM('user', 'assistant') NOT NULL,
    content TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- TABEL AUDIT LOGS (FIX: metadata TEXT)
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(50),
    action VARCHAR(100),
    table_name VARCHAR(100),
    record_id VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    metadata TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE SET NULL,
FOREIGN KEY (produk_id) REFERENCES produk(id) ON DELETE CASCADE
