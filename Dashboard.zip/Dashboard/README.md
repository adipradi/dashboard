## 📊 GAMBARAN UMUM PROYEK

Membuat aplikasi dashboard interaktif berbasis chatbot (menggunakan ChatGPT API) dengan kemampuan sebagai berikut:

* Menjawab pertanyaan bahasa alami tentang data
* Mengakses database internal (MySQL/PostgreSQL)
* Mengakses data eksternal seperti YouTube Analytics dan Website Analytics
* Menyediakan visualisasi data secara real-time
* Membatasi akses berdasarkan login dan role pengguna
* Logging aktivitas pengguna dan riwayat percakapan
* Ekspor laporan ke Excel atau PDF
* Menjadwalkan update data secara otomatis
* Fitur download data hasil filter
* Manajemen data langsung di dashboard (add/edit/delete data)

---

## 🏗️ ARSITEKTUR SISTEM (High-Level)

```
                      +-----------------+
                      |     User        |
                      +--------+--------+
                               |
                    Natural Language Input
                               |
                               v
          +--------------------------+
          |  ChatGPT Agent (OpenAI)  |
          +--------------------------+
                   |         |
        SQL Query / API Call         \
           |                          \
+----------v----------+        +-------v--------+
|  DB Service (MySQL) |        | YouTube/Web API|
+----------+----------+        +-------+--------+
           |                           |
           +-----------+--------------+
                       |
                  +----v----+
                  | DataFrame|
                  +----+----+
                       |
                +------v------+
                | Visualization|
                +-------------+

     +-----------------------------------+
     | Streamlit Frontend (with Login)  |
     +-----------------------------------+
```

---

## 📁 STRUKTUR FOLDER LENGKAP

```
project_dashboard_ai/
│
├── app.py                           # Entry point (Streamlit)
├── requirements.txt
├── .env                             # API keys & DB credentials
│
├── config/                          # Konfigurasi sistem
│   ├── settings.py                  # Load .env dan konversi variabel
│   └── users.yaml                   # User login data & role
│
├── auth/                            # Login & auth
│   ├── login.py                     # Form login dan validasi
│   └── auth_utils.py                # Hashing & cek role
│
├── pages/                           # Halaman dashboard (tab)
│   ├── 1_Chat_SQL.py
│   ├── 2_YouTube_Analytics.py
│   ├── 3_Website_Analytics.py
│   ├── 4_Visual_Insights.py
│   └── 5_Data_Manager.py            # ✅ Halaman CRUD data
│
├── services/                        # Ambil data dari sumber eksternal
│   ├── chatgpt_agent.py
│   ├── db_service.py
│   ├── youtube_service.py
│   └── web_analytics_service.py
│
├── controllers/                     # Logika pengolahan
│   ├── chatbot_controller.py
│   ├── sql_controller.py
│   ├── youtube_controller.py
│   ├── web_analytics_controller.py
│   └── data_manager_controller.py   # ✅ CRUD data
│
├── models/                          # Data models & schema
│   ├── user_model.py
│   ├── youtube_models.py
│   ├── web_analytics_models.py
│   └── data_schema.py               # ✅ Struktur tabel data
│
├── components/                      # Komponen UI (sidebar, header, dll)
│   ├── sidebar.py
│   └── header.py
│
├── utils/                           # Fungsi umum (grafik, export)
│   ├── visualizer.py
│   ├── file_handler.py
│   └── formatter.py
│
└── assets/                          # Logo, CSS
    ├── logo.png
    └── style.css
```

---

## 🔐 LOGIN & ROLE-BASED ACCESS CONTROL (RBAC)

* Login via `st.text_input()` dan `st.session_state`
* Password disimpan dalam bentuk hash menggunakan bcrypt
* File `users.yaml` menyimpan data:

```yaml
users:
  - username: admin
    password: $2b$12$hashed_pass_here
    role: admin
  - username: analyst
    password: $2b$12$hashed_pass_here
    role: analyst
```

| Role    | Hak Akses                                    |
| ------- | -------------------------------------------- |
| admin   | Semua halaman, bisa hapus/edit data          |
| analyst | Bisa query data dan lihat grafik             |
| viewer  | Hanya lihat grafik dan statistik, tidak edit |

---

## 🤖 CHATBOT (ChatGPT Agent)

### Fungsi:

* Menerima pertanyaan dari user, contoh:

  * "Tampilkan produk terlaris bulan ini"
  * "Grafik views YouTube minggu ini"
* Agent akan:

  1. Deteksi maksud (intent)
  2. Ubah ke SQL / API call
  3. Eksekusi query atau panggil API
  4. Kembalikan hasil sebagai jawaban/grafik

### Contoh Kode:

```python
response = openai.ChatCompletion.create(
  model="gpt-4",
  messages=[
    {"role": "system", "content": "You are a data analyst."},
    {"role": "user", "content": user_input}  # user_input = pertanyaan dari pengguna
  ]
)
```

---

## 🔌 INTEGRASI DATA REAL-TIME

* Query database pakai `mysql.connector` atau `psycopg2`
* Data: produk terlaris, transaksi terbanyak, dsb.
* Ambil statistik YouTube: views, CTR, subscribers
* Gunakan `google-api-python-client`

### Contoh endpoint:

```python
youtubeAnalytics.reports().query(...)
```

* Website analytics bisa pakai Google Analytics API atau Matomo (open source)

### Data yang diambil:

* Halaman terpopuler
* Bounce rate
* Asal traffic

---

## 📊 VISUALISASI REAL-TIME

### Tools:

* Plotly → grafik interaktif (line, bar, pie)
* Altair → grafik yang ringan dan estetik
* `st.dataframe` → tampilan tabular

### Contoh Kode:

```python
fig = px.line(df, x="date", y="views", title="7 Hari Terakhir YouTube Views")
st.plotly_chart(fig)
```

---

## ⚙️ CARA KERJA APLIKASI (STEP-BY-STEP)

1. User buka `app.py` → login form tampil
2. Setelah login:

   * Data user disimpan di `st.session_state`
   * Role diidentifikasi
3. Dashboard menampilkan tab sesuai role
4. User ketik pertanyaan → dikirim ke ChatGPT
5. Agent ubah jadi SQL/API call
6. Hasil query divisualisasikan
7. Semua data diambil langsung dari sumber (real-time)
8. Aktivitas dan chat dicatat dalam sistem log
9. **Admin bisa kelola data langsung di dashboard (CRUD)**

---

## 🧪 TEKNOLOGI YANG DIGUNAKAN

| Komponen             | Teknologi                       |
| -------------------- | ------------------------------- |
| Frontend UI          | Streamlit                       |
| Autentikasi          | Streamlit Session, bcrypt       |
| Chatbot              | OpenAI ChatGPT API              |
| Database             | MySQL / PostgreSQL              |
| YouTube Analytics    | YouTube Data API v3             |
| Website Analytics    | Google Analytics API / Matomo   |
| Visualisasi          | Plotly, Altair                  |
| Format Data          | Pandas                          |
| Ekspor Laporan       | openpyxl, fpdf                  |
| Logging Aktivitas    | Python Logging, SQLite/DB       |
| Penjadwalan Otomatis | APScheduler, cron               |
| CRUD Data            | SQLAlchemy / Pandas + Streamlit |

---

## ✅ FITUR WAJIB (SIAP PRODUKSI)

* **Logging semua aktivitas user dan riwayat percakapan**
* **Ekspor laporan ke Excel atau PDF**
* **Jadwal otomatis update data (harian/mingguan)**
* **Fitur download data hasil filter**
* **Manajemen data langsung dari dashboard (tambah, edit, hapus)**

---

## 🚀 LANGKAH SELANJUTNYA

| Tujuan                         | Perintah yang Bisa Diberi                          |
| ------------------------------ | -------------------------------------------------- |
| Buat semua file & folder dasar | "generate semua template folder dan file dasar"    |
| Fokus ke sistem login          | "buatkan sistem login + role + proteksi halaman"   |
| Fokus ke ChatGPT agent         | "buatkan agent ChatGPT yang bisa jawab pertanyaan" |
| Fokus ke YouTube Analytics     | "buatkan koneksi YouTube API + grafik"             |
| Fokus ke Manajemen Data        | "buatkan halaman untuk tambah/edit/hapus data"     |
| Jalankan semua step bertahap   | "lanjut step 1 dari setup proyek ini"              |